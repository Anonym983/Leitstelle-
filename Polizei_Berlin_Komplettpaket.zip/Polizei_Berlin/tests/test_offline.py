import ast
import importlib.util
import json
import sqlite3
import tempfile
import types
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def standalone(name,filename):
    spec=importlib.util.spec_from_file_location(name,ROOT/filename)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
class DomainTests(unittest.TestCase):
    def setUp(self):
        self.db=sqlite3.connect(":memory:")
        self.db.row_factory=sqlite3.Row
        self.db.executescript("""CREATE TABLE dienstnummern(nummer TEXT PRIMARY KEY,user_id INTEGER UNIQUE,roblox TEXT);
        CREATE TABLE dienst_aktiv(user_id INTEGER PRIMARY KEY,start REAL);
        CREATE TABLE dienst_log(id INTEGER PRIMARY KEY,user_id INTEGER,start REAL,ende REAL);""")
        names={"alle_nummern","nummer_von","roblox_von","besitzer_von","freie_nummern","naechste_freie","nummer_normalisieren","nummer_zuweisen","nummer_freigeben","nummer_zahl","aufruecken","dienstzeit_summe","dienst_beenden"}
        tree=ast.parse((ROOT/"polizei/core.py").read_text(encoding="utf-8"))
        nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
        self.ns={"db":self.db,"NUMMER_PREFIX":"BLP","MAX_NUMMERN":500,"time":types.SimpleNamespace(time=lambda:10000)}
        exec(compile(ast.Module(body=nodes,type_ignores=[]),"domain-test","exec"),self.ns)
    def tearDown(self):self.db.close()
    def test_normalize(self):
        self.assertEqual(self.ns["nummer_normalisieren"](" 5 "),"BLP05")
        self.assertIsNone(self.ns["nummer_normalisieren"]("0"))
    def test_assignment(self):
        self.assertEqual(self.ns["nummer_zuweisen"](1),("BLP01",None))
        self.assertEqual(self.ns["nummer_zuweisen"](1),("BLP01",None))
    def test_swap(self):
        self.ns["nummer_zuweisen"](1,roblox="Name_A")
        self.ns["nummer_zuweisen"](2,roblox="Name_B")
        self.assertEqual(self.ns["nummer_zuweisen"](2,"BLP01"),("BLP01",(1,"BLP02")))
        self.assertEqual(self.ns["roblox_von"](1),"Name_A")
    def test_gap(self):
        self.ns["nummer_zuweisen"](1)
        self.ns["nummer_zuweisen"](2)
        self.ns["nummer_freigeben"](1)
        self.assertEqual(self.ns["aufruecken"]("BLP01"),[(2,"BLP02","BLP01")])
    def test_occupied(self):
        self.ns["nummer_zuweisen"](1)
        with self.assertRaises(ValueError):self.ns["aufruecken"]("BLP01")
    def test_duty(self):
        self.db.execute("INSERT INTO dienst_aktiv VALUES(1,9000)");self.db.commit()
        self.assertEqual(self.ns["dienstzeit_summe"](1,9500),500)
        self.assertEqual(self.ns["dienst_beenden"](1,10000),1000)
        self.assertIsNone(self.ns["dienst_beenden"](1))
        self.assertEqual(self.ns["dienstzeit_summe"](1,9700),300)
class StructureTests(unittest.TestCase):
    def test_compile(self):
        for p in ROOT.rglob("*.py"):compile(p.read_text(encoding="utf-8"),str(p),"exec")
    def test_commands(self):
        expected=json.loads((ROOT/"BEFEHLE.json").read_text(encoding="utf-8"));actual={}
        for n in ast.walk(ast.parse((ROOT/"polizei/core.py").read_text(encoding="utf-8"))):
            if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
                for d in n.decorator_list:
                    if isinstance(d,ast.Call) and isinstance(d.func,ast.Attribute) and d.func.attr=="command":
                        name=next((kw.value.value for kw in d.keywords if kw.arg=="name"),n.name)
                        actual[name]=[a.arg for a in n.args.args]
        self.assertEqual(actual,expected)
        self.assertEqual(len(actual),35)
    def test_backup(self):
        module=standalone("storage_test","polizei/storage.py")
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/"polizei.db";db=module.open_database(p)
            with db:db.execute("CREATE TABLE sample(value INTEGER)");db.execute("INSERT INTO sample VALUES(42)")
            db.close();db=module.open_database(p)
            self.assertEqual(db.execute("SELECT value FROM sample").fetchone()[0],42)
            backups=list((Path(folder)/"backups").glob("*.db"));self.assertEqual(len(backups),1)
            with sqlite3.connect(backups[0]) as b:self.assertEqual(b.execute("SELECT value FROM sample").fetchone()[0],42)
            db.close()
    def test_templates(self):
        design=standalone("design_test","polizei/design.py");preview=standalone("preview_test","vorschau_erstellen.py")
        self.assertEqual(len(design.DESIGN["templates"]),33)
        for k,t in design.DESIGN["templates"].items():
            text=t["text"].format_map(preview.SAMPLES)
            self.assertLessEqual(len(text),4096,k);self.assertLessEqual(len(t["titel"]),256,k)
            self.assertNotIn("__",text)
    def test_headings(self):
        m=standalone("heading_test","polizei/design.py")
        self.assertEqual(m.field_heading("Beamter"),"Beamter:")
        self.assertEqual(m.field_heading("Beamter:"),"Beamter:")
    def test_preview(self):
        content=(ROOT/"VORSCHAU.html").read_text(encoding="utf-8")
        self.assertIn("design.json herunterladen",content)
        self.assertIn("keine echte Discord-Aufnahme",content)
        self.assertIn("Keine Bot-Tokens",content)
        self.assertNotIn("POLIZEI BERLIN · RP-VERWALTUNG",content)
if __name__=="__main__":unittest.main()
