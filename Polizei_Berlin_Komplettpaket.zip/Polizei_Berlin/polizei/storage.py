import datetime
import sqlite3
from pathlib import Path

def open_database(filename):
    path=Path(filename)
    path.parent.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(str(path),timeout=15)
    db.row_factory=sqlite3.Row
    try:
        if path.stat().st_size:
            folder=path.parent/"backups"
            folder.mkdir(exist_ok=True)
            stamp=datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
            with sqlite3.connect(str(folder/f"polizei-{stamp}.db")) as backup:
                db.backup(backup)
            for old in sorted(folder.glob("polizei-*.db"))[:-5]:
                old.unlink()
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("PRAGMA busy_timeout=15000")
        db.execute("PRAGMA synchronous=FULL")
        if db.execute("PRAGMA quick_check").fetchone()[0]!="ok":
            raise RuntimeError("Datenbankprüfung fehlgeschlagen.")
        return db
    except Exception:
        db.close()
        raise

def create_indexes(db):
    with db:
        for sql in ["CREATE INDEX IF NOT EXISTS idx_warns_user_ablauf ON warns(user_id,ablauf)","CREATE INDEX IF NOT EXISTS idx_dienstlog_user_ende ON dienst_log(user_id,ende)","CREATE INDEX IF NOT EXISTS idx_antraege_message ON antraege(message_id)","CREATE INDEX IF NOT EXISTS idx_checks_frist ON aktivitaetschecks(abgeschlossen,frist)","CREATE INDEX IF NOT EXISTS idx_ausbildung_message ON ausbildung(message_id)"]:
            db.execute(sql)
