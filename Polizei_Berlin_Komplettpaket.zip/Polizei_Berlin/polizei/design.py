import json
import string
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
class SafeValues(dict):
    def __missing__(self, key):
        return "{" + key + "}"

def load_design(path=None):
    with Path(path or ROOT / "design.json").open(encoding="utf-8") as handle:
        design = json.load(handle)
    for key in ("branding", "templates", "texte_weitere"):
        if not isinstance(design.get(key),dict):
            raise ValueError(f"Ungültiger Designbereich: {key}")
    if design["branding"].get("banner_mode") not in ("attachment","url","none"):
        raise ValueError("banner_mode muss attachment, url oder none sein.")
    formatter=string.Formatter()
    for key,t in design["templates"].items():
        if not all(k in t for k in ("titel","text","farbe")):
            raise ValueError(f"Unvollständige Vorlage: {key}")
        if not isinstance(t["farbe"],int) or not 0 <= t["farbe"] <= 0xFFFFFF:
            raise ValueError(f"Ungültiger Farbwert: {key}")
        list(formatter.parse(t["titel"]))
        list(formatter.parse(t["text"]))
    for text in design["texte_weitere"].values():
        list(formatter.parse(text))
    return design

DESIGN=load_design()
def ui_text(key,**values):
    return DESIGN["texte_weitere"][key].format_map(SafeValues(values))
def field_heading(value):
    value=str(value)
    return value if not value.strip() or value=="\u200b" else value.rstrip(":")+":"
