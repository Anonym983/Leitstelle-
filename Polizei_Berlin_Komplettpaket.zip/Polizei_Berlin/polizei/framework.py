import logging
from pathlib import Path
import discord
from discord import app_commands

log=logging.getLogger("polizei.interactions")
BANNER=Path(__file__).resolve().parents[1]/"polizei_berlin_banner.png"
async def send_with_branding(method,*args,**kwargs):
    embeds=list(kwargs.get("embeds") or [])
    if kwargs.get("embed") is not None:embeds.append(kwargs["embed"])
    if any(getattr(e.image,"url",None)=="attachment://polizei_berlin_banner.png" for e in embeds):
        if not BANNER.is_file():raise ValueError("Die Bannerdatei fehlt.")
        files=list(kwargs.pop("files",[]) or [])
        one=kwargs.pop("file",None)
        if one is not None:files.append(one)
        if not any(getattr(f,"filename",None)==BANNER.name for f in files):
            files.append(discord.File(BANNER,filename=BANNER.name))
        if len(files)>10:raise ValueError("Zu viele Dateianhänge.")
        kwargs["files"]=files
        try:return await method(*args,**kwargs)
        finally:
            for f in files:
                if hasattr(f,"close"):f.close()
    return await method(*args,**kwargs)

async def respond_error(interaction,error):
    log.error("Interaktion fehlgeschlagen",exc_info=(type(error),error,error.__traceback__))
    text=str(error) if isinstance(error,ValueError) else "❌ Die Aktion konnte nicht vollständig ausgeführt werden. Bitte die Bot-Verwaltung informieren."
    try:
        if interaction.response.is_done():await interaction.followup.send(text,ephemeral=True)
        else:await interaction.response.send_message(text,ephemeral=True)
    except discord.HTTPException:log.warning("Fehlermeldung konnte nicht zugestellt werden")

async def guild_check(interaction):
    from . import core as ctx
    if interaction.guild is None or (ctx.GUILD_ID and interaction.guild_id!=ctx.GUILD_ID):
        await interaction.response.send_message("❌ Nur auf dem konfigurierten RP-Server verfügbar.",ephemeral=True)
        return False
    return True
class SafeCommandTree(app_commands.CommandTree):
    async def interaction_check(self,interaction):return await guild_check(interaction)
class SafeView(discord.ui.View):
    async def interaction_check(self,interaction):return await guild_check(interaction)
    async def on_error(self,interaction,error,item):await respond_error(interaction,error)
class SafeModal(discord.ui.Modal):
    async def interaction_check(self,interaction):
        if not await guild_check(interaction):return False
        from . import core as ctx
        required={"PlatzverweisModal":"police","DienstausweisModal":"police","DatenbankAbfrageModal":"police","AufrueckenModal":"lead","AblehnenModal":"lead"}.get(type(self).__name__)
        allowed=True
        if required=="lead":allowed=ctx.ist_fuehrung_member(interaction.user)
        elif required=="police":allowed=ctx.hat_hauptrolle(interaction.user) or ctx.ist_fuehrung_member(interaction.user)
        if not allowed:await interaction.response.send_message("❌ Berechtigung nicht mehr vorhanden.",ephemeral=True)
        return allowed
    async def on_error(self,interaction,error):await respond_error(interaction,error)
class Confirmation(SafeView):
    def __init__(self,owner):
        super().__init__(timeout=60)
        self.owner=owner
        self.accepted=False
    async def interaction_check(self,interaction):
        if interaction.user.id!=self.owner:
            await interaction.response.send_message("Diese Bestätigung gehört einer anderen Person.",ephemeral=True)
            return False
        return await super().interaction_check(interaction)
    @discord.ui.button(label="Verbindlich bestätigen",style=discord.ButtonStyle.danger)
    async def accept(self,interaction,button):
        if self.is_finished():return await interaction.response.send_message("Bereits beendet.",ephemeral=True)
        self.accepted=True
        await interaction.response.edit_message(content="Bestätigt. Aktion wird verarbeitet.",view=None)
        self.stop()
    @discord.ui.button(label="Abbrechen",style=discord.ButtonStyle.secondary)
    async def cancel(self,interaction,button):
        await interaction.response.edit_message(content="Aktion abgebrochen.",view=None)
        self.stop()
async def confirm_action_local(interaction,text):
    view=Confirmation(interaction.user.id)
    message=await interaction.followup.send(text,view=view,ephemeral=True,wait=True,allowed_mentions=discord.AllowedMentions.none())
    if await view.wait():
        try:await message.edit(content="Bestätigung abgelaufen. Keine Änderung durchgeführt.",view=None)
        except discord.HTTPException:pass
    return view.accepted
