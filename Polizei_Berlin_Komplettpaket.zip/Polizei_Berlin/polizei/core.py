from .configuration import *
from .logging_setup import log_print as print

if not TOKEN:
    raise SystemExit('❌ FEHLER: Umgebungsvariable DISCORD_TOKEN fehlt!')
RANG_INFO = {rid: (name, gruppe) for name, rid, gruppe in TEAMLISTE_RAENGE}
try:
    from zoneinfo import ZoneInfo
    TZ = ZoneInfo(ZEITZONE)
except Exception:
    TZ = datetime.timezone.utc
WOCHENBERICHT_ZEIT = datetime.time(hour=WOCHENBERICHT_UHRZEIT[0], minute=WOCHENBERICHT_UHRZEIT[1], tzinfo=TZ)
os.makedirs(DATA_DIR, exist_ok=True)
db = open_database(os.path.join(DATA_DIR, 'polizei.db'))
db.row_factory = sqlite3.Row
db.executescript("\nCREATE TABLE IF NOT EXISTS dienstnummern (nummer TEXT PRIMARY KEY, user_id INTEGER UNIQUE NOT NULL, roblox TEXT);\nCREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);\nCREATE TABLE IF NOT EXISTS warns (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, grund TEXT, von INTEGER, erstellt REAL, ablauf REAL, az TEXT);\nCREATE TABLE IF NOT EXISTS antraege (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, typ TEXT, name TEXT, geburtstag TEXT, roblox TEXT, message_id INTEGER, status TEXT DEFAULT 'offen');\nCREATE TABLE IF NOT EXISTS dienst_aktiv (user_id INTEGER PRIMARY KEY, start REAL);\nCREATE TABLE IF NOT EXISTS dienst_log (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, start REAL, ende REAL);\nCREATE TABLE IF NOT EXISTS aktivitaetschecks (id INTEGER PRIMARY KEY AUTOINCREMENT, message_id INTEGER, channel_id INTEGER, start REAL, frist REAL, abgeschlossen INTEGER DEFAULT 0);\nCREATE TABLE IF NOT EXISTS aktivitaet_bestaetigt (check_id INTEGER, user_id INTEGER, PRIMARY KEY (check_id, user_id));\nCREATE TABLE IF NOT EXISTS bewerbungssperren (user_id INTEGER PRIMARY KEY, grund TEXT, ablauf REAL, von INTEGER);\nCREATE TABLE IF NOT EXISTS suspendierungen (user_id INTEGER PRIMARY KEY, grund TEXT, von INTEGER, seit REAL);\nCREATE TABLE IF NOT EXISTS dienstsperren (user_id INTEGER PRIMARY KEY, grund TEXT, von INTEGER, ablauf REAL);\nCREATE TABLE IF NOT EXISTS aufrueck_offen (message_id INTEGER PRIMARY KEY, nummer TEXT, erledigt INTEGER DEFAULT 0);\nCREATE TABLE IF NOT EXISTS ausbildung (user_id INTEGER PRIMARY KEY, ausbilder_id INTEGER, gestartet REAL, message_id INTEGER, channel_id INTEGER, abgeschlossen INTEGER DEFAULT 0);\nCREATE TABLE IF NOT EXISTS ausbildung_module (user_id INTEGER, modul INTEGER, erledigt REAL, von INTEGER, PRIMARY KEY (user_id, modul));\n")
try:
    db.execute('ALTER TABLE warns ADD COLUMN az TEXT')
except sqlite3.OperationalError:
    pass
db.commit()
create_indexes(db)

def alte_json_importieren():
    """Übernimmt Nummern aus der alten dienstnummern.json (nummer -> user_id)."""
    pfad = 'dienstnummern.json'
    if not os.path.exists(pfad) or db.execute('SELECT 1 FROM dienstnummern LIMIT 1').fetchone():
        return
    try:
        with open(pfad, 'r') as f:
            alt = json.load(f)
        with db:
            for nummer, uid in alt.items():
                db.execute('INSERT OR IGNORE INTO dienstnummern (nummer, user_id) VALUES (?, ?)', (nummer, uid))
        print(f'📥 {len(alt)} Dienstnummern aus alter JSON importiert.')
    except Exception as e:
        print('Import der alten JSON fehlgeschlagen:', e)
alte_json_importieren()

def setting_get(key):
    r = db.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
    return r['value'] if r else None

def setting_set(key, value):
    with db:
        db.execute('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (key, str(value)))

def alle_nummern():
    return [f'{NUMMER_PREFIX}{i:02d}' for i in range(1, MAX_NUMMERN + 1)]

def nummer_von(user_id):
    r = db.execute('SELECT nummer FROM dienstnummern WHERE user_id=?', (user_id,)).fetchone()
    return r['nummer'] if r else None

def nummer_tag(user_id):
    n = nummer_von(user_id)
    return f' [{n}]' if n else ''

def roblox_von(user_id):
    r = db.execute('SELECT roblox FROM dienstnummern WHERE user_id=?', (user_id,)).fetchone()
    return r['roblox'] if r else None

def besitzer_von(nummer):
    r = db.execute('SELECT user_id FROM dienstnummern WHERE nummer=?', (nummer,)).fetchone()
    return r['user_id'] if r else None

def freie_nummern():
    belegt = {r['nummer'] for r in db.execute('SELECT nummer FROM dienstnummern')}
    return [n for n in alle_nummern() if n not in belegt]

def naechste_freie():
    f = freie_nummern()
    return f[0] if f else None

def nummer_normalisieren(text):
    t = text.upper().strip()
    if t.startswith(NUMMER_PREFIX):
        t = t[len(NUMMER_PREFIX):]
    if not t.isdigit() or not 1 <= int(t) <= MAX_NUMMERN:
        return None
    return f'{NUMMER_PREFIX}{int(t):02d}'

def nummer_zuweisen(user_id, wunsch=None, roblox=None):
    """Gibt (nummer, verdraengt) zurück. verdraengt = (user_id, neue_nummer) oder None.
    Wirft ValueError, wenn nichts frei ist."""
    alte = nummer_von(user_id)
    roblox = roblox or roblox_von(user_id)
    verdraengt = None
    with db:
        if wunsch is None:
            if alte:
                if roblox:
                    db.execute('UPDATE dienstnummern SET roblox=? WHERE user_id=?', (roblox, user_id))
                return (alte, None)
            ziel = naechste_freie()
            if not ziel:
                raise ValueError('Es sind keine Dienstnummern mehr frei.')
        else:
            ziel = wunsch
            if alte == ziel:
                if roblox:
                    db.execute('UPDATE dienstnummern SET roblox=? WHERE user_id=?', (roblox, user_id))
                return (ziel, None)
            besitzer = besitzer_von(ziel)
            if besitzer is not None:
                ersatz = alte or naechste_freie()
                if not ersatz:
                    raise ValueError('Keine freie Nummer zum Tauschen vorhanden.')
                besitzer_roblox = roblox_von(besitzer)
                db.execute('DELETE FROM dienstnummern WHERE user_id=?', (besitzer,))
                db.execute('DELETE FROM dienstnummern WHERE user_id=?', (user_id,))
                db.execute('INSERT INTO dienstnummern (nummer, user_id, roblox) VALUES (?, ?, ?)', (ersatz, besitzer, besitzer_roblox))
                verdraengt = (besitzer, ersatz)
        db.execute('DELETE FROM dienstnummern WHERE user_id=?', (user_id,))
        db.execute('INSERT INTO dienstnummern (nummer, user_id, roblox) VALUES (?, ?, ?)', (ziel, user_id, roblox))
    return (ziel, verdraengt)

def nummer_freigeben(user_id):
    nummer = nummer_von(user_id)
    if nummer:
        with db:
            db.execute('DELETE FROM dienstnummern WHERE user_id=?', (user_id,))
    return nummer

def ist_fuehrung_member(m):
    return isinstance(m, discord.Member) and (m.guild_permissions.administrator or any((r.id in ROLLEN_FUEHRUNG for r in m.roles)))

def ist_ausbilder_member(m):
    return ist_fuehrung_member(m) or (isinstance(m, discord.Member) and any((RANG_INFO.get(r.id, (None, None))[1] == 'Ausbilder' for r in m.roles)))

def ist_fuehrung():
    return app_commands.check(lambda i: ist_fuehrung_member(i.user))

def ist_ausbilder():
    return app_commands.check(lambda i: ist_ausbilder_member(i.user))

def hat_hauptrolle(m):
    return any((r.id == ROLLE_HAUPT_POLIZEI for r in m.roles))

def ping(mention):
    """Gibt die Erwähnung nur zurück, wenn MELDUNG_PING aktiv ist (sonst kein Ping über der Meldung)."""
    return mention if MELDUNG_PING else None

def basis_embed(titel, beschreibung=None, farbe=1533423):
    e = discord.Embed(title=titel, description=beschreibung, color=farbe, timestamp=discord.utils.utcnow())
    e.set_footer(text=DESIGN['branding']['footer'])
    mode = DESIGN['branding'].get('banner_mode', 'attachment')
    if mode == 'attachment':
        e.set_image(url='attachment://polizei_berlin_banner.png')
    elif mode == 'url' and os.getenv('EMBED_BANNER_URL', '').startswith('https://'):
        e.set_image(url=os.environ['EMBED_BANNER_URL'])
    return e

class _Sicher(dict):
    """Unbekannte Platzhalter bleiben stehen, statt den Bot abstürzen zu lassen."""

    def __missing__(self, key):
        return '{' + key + '}'

def text_embed(key, farbe=None, **kw):
    t = TEXTE[key]
    values = dict(kw)
    values.setdefault('zeitpunkt', discord.utils.format_dt(discord.utils.utcnow(), 't'))
    values.setdefault('dienstnummer', 'Nicht vergeben')
    match = re.search('<@!?(\\d+)>', str(values.get('user', '')))
    if match:
        values['dienstnummer'] = nummer_von(int(match.group(1))) or 'Nicht vergeben'
    values.setdefault('warn_hinweis', 'Wer nicht fristgerecht bestätigt, erhält automatisch eine Dienst-Warn.' if AKTIVITAETSCHECK_AUTO_WARN else 'Die Führung wertet die Rückmeldungen nach Ablauf aus.')
    safe = _Sicher(**values)
    return basis_embed(t['titel'].format_map(safe), t['text'].format_map(safe), farbe if farbe is not None else t['farbe'])

def dauer_text(sekunden):
    s = int(sekunden)
    return f'{s // 3600}h {s % 3600 // 60}min'

def chunk_text(items, limit=1000):
    bloecke, aktuell = ([], '')
    for item in items:
        teil = f'{item}, '
        if len(aktuell) + len(teil) > limit:
            bloecke.append(aktuell.rstrip(', '))
            aktuell = ''
        aktuell += teil
    if aktuell:
        bloecke.append(aktuell.rstrip(', '))
    return bloecke

def fmt_zeit(ts, stil='F'):
    return discord.utils.format_dt(datetime.datetime.fromtimestamp(ts, datetime.timezone.utc), stil)

def hauptguild():
    if GUILD_ID:
        return bot.get_guild(GUILD_ID)
    return bot.guilds[0] if bot.guilds else None

def dz_log(fuehrung=False):
    """Log-Kanal für Dienstzeit-Meldungen."""
    basis = KANAL_DIENSTZEIT_LOG or KANAL_DIENSTZEIT
    return KANAL_DIENSTZEIT_LOG_FUEHRUNG or basis if fuehrung else basis

async def senden(kanal_id, **kwargs):
    kanal = bot.get_channel(kanal_id)
    if kanal is None:
        print(f'⚠️ Kanal {kanal_id} nicht gefunden (ID falsch oder Bot hat keinen Zugriff).')
        return None
    try:
        return await send_with_branding(kanal.send, **kwargs)
    except discord.HTTPException as e:
        print(f'⚠️ Senden in Kanal {kanal_id} fehlgeschlagen: {e}')
        return None

async def rollen_aendern(member, add=(), remove=(), grund=''):
    """Gibt None bei Erfolg zurück, sonst eine Fehlermeldung."""
    me = member.guild.me
    if me is None or not me.guild_permissions.manage_roles:
        return 'Dem Bot fehlt die Berechtigung Rollen verwalten.'
    if member.id == member.guild.owner_id or member.top_role >= me.top_role:
        return 'Dieses Mitglied steht außerhalb der verwaltbaren Rollenhierarchie.'
    for r in list(add) + list(remove):
        if r.is_default() or r.managed:
            return 'Standard- und Integrationsrollen können nicht geändert werden.'
        if r >= me.top_role:
            return f'Die Rolle {r.mention} steht über oder gleich der Bot-Rolle. Bitte die Bot-Rolle in den Servereinstellungen nach oben ziehen.'
    try:
        if remove:
            await member.remove_roles(*remove, reason=grund)
        if add:
            await member.add_roles(*add, reason=grund)
    except discord.Forbidden:
        return 'Dem Bot fehlt die Berechtigung „Rollen verwalten“ oder die Rolle steht zu hoch.'
    except discord.HTTPException as e:
        return f'Discord-Fehler: {e}'
    return None

async def sonderrolle(member, rolle_id, geben, grund):
    """Vergibt oder entfernt eine Sonderrolle (Warn/Suspendiert/Entlassen). None = ok oder Funktion aus."""
    if not rolle_id or member is None:
        return None
    rolle = member.guild.get_role(rolle_id)
    if rolle is None:
        return f'Rolle {rolle_id} nicht gefunden'
    if geben and rolle not in member.roles:
        return await rollen_aendern(member, add=[rolle], grund=grund)
    if not geben and rolle in member.roles:
        return await rollen_aendern(member, remove=[rolle], grund=grund)
    return None

async def warn_rollen_setzen(user_id, grund):
    """Setzt die passende Warn-Rolle (Warn 1/2/3) anhand der aktiven Warns. Gibt Fehlermeldung oder None zurück."""
    g = hauptguild()
    member = g.get_member(user_id) if g else None
    if member is None or not any(ROLLEN_WARN):
        return None
    aktiv = db.execute('SELECT COUNT(*) c FROM warns WHERE user_id=? AND ablauf>?', (user_id, time.time())).fetchone()['c']
    ziel = None
    if aktiv > 0 and hat_hauptrolle(member):
        ziel = ROLLEN_WARN[min(aktiv, len(ROLLEN_WARN)) - 1]
    fehler = None
    for rid in ROLLEN_WARN:
        f = await sonderrolle(member, rid, rid == ziel, grund)
        fehler = fehler or f
    return fehler
NICK_RE = re.compile(f'^{NUMMER_PREFIX}\\d+\\s*\\|\\s*')

async def nick_setzen(member, nummer):
    if not AUTO_NICKNAME:
        return
    basis = NICK_RE.sub('', member.display_name)
    try:
        await member.edit(nick=f'{nummer} | {basis}'[:32], reason='Dienstnummer')
    except discord.HTTPException:
        pass

async def nick_zuruecksetzen(member):
    if not AUTO_NICKNAME or not NICK_RE.match(member.display_name):
        return
    neu = NICK_RE.sub('', member.display_name) or None
    try:
        await member.edit(nick=neu, reason='Dienstnummer entzogen')
    except discord.HTTPException:
        pass

def nummer_zahl(nummer):
    try:
        return int(nummer[len(NUMMER_PREFIX):])
    except (ValueError, TypeError):
        return 0

def freie_bereiche():
    """Freie Nummern als kompakte Bereiche, z. B. BLP02–BLP99, BLP101."""
    zahlen = [nummer_zahl(n) for n in freie_nummern()]
    if not zahlen:
        return '*keine*'
    bereiche, start, prev = ([], zahlen[0], zahlen[0])
    for z in zahlen[1:]:
        if z == prev + 1:
            prev = z
            continue
        bereiche.append((start, prev))
        start = prev = z
    bereiche.append((start, prev))
    return ', '.join((f'{NUMMER_PREFIX}{a:02d}' if a == b else f'{NUMMER_PREFIX}{a:02d}–{NUMMER_PREFIX}{b:02d}' for a, b in bereiche))

def aufruecken(ab_nummer):
    """Schließt die Lücke bei ab_nummer: Alle höheren Nummern rücken lückenlos nach.
    Gibt [(user_id, alte_nummer, neue_nummer)] zurück. Wirft ValueError, wenn die Nummer noch vergeben ist."""
    g = nummer_zahl(ab_nummer)
    rows = db.execute('SELECT nummer, user_id, roblox FROM dienstnummern').fetchall()
    if any((nummer_zahl(r['nummer']) == g for r in rows)):
        raise ValueError(f'{ab_nummer} ist inzwischen wieder vergeben – es gibt nichts aufzurücken.')
    hoeher = sorted((r for r in rows if nummer_zahl(r['nummer']) > g), key=lambda r: nummer_zahl(r['nummer']))
    aenderungen, ziel = ([], g)
    with db:
        db.execute('DELETE FROM dienstnummern WHERE CAST(SUBSTR(nummer, ?) AS INTEGER) > ?', (len(NUMMER_PREFIX) + 1, g))
        for r in hoeher:
            neu = f'{NUMMER_PREFIX}{ziel:02d}'
            db.execute('INSERT INTO dienstnummern (nummer, user_id, roblox) VALUES (?, ?, ?)', (neu, r['user_id'], r['roblox']))
            if neu != r['nummer']:
                aenderungen.append((r['user_id'], r['nummer'], neu))
            ziel += 1
    return aenderungen

async def panel_aktualisieren():
    """Das automatische Live-Panel mit allen freien Nummern gibt es nicht mehr.
    Diese Funktion löscht nur einmalig die alte Panel-Nachricht, falls noch eine existiert."""
    msg_id = setting_get('panel_message_id')
    if not msg_id:
        return
    kanal = bot.get_channel(KANAL_DIENSTNUMMER_PANEL)
    if kanal is not None:
        try:
            msg = await kanal.fetch_message(int(msg_id))
            await msg.delete()
        except discord.HTTPException:
            pass
    setting_set('panel_message_id', '')

def dienstzeit_summe(user_id, seit):
    total = 0.0
    for r in db.execute('SELECT start, ende FROM dienst_log WHERE user_id=? AND ende>?', (user_id, seit)):
        total += r['ende'] - max(r['start'], seit)
    a = db.execute('SELECT start FROM dienst_aktiv WHERE user_id=?', (user_id,)).fetchone()
    if a:
        total += time.time() - max(a['start'], seit)
    return total

def dienst_beenden(user_id, ende=None):
    """Stempelt aus und schreibt ins Log. Gibt die Dauer in Sekunden zurück (None, wenn nicht im Dienst)."""
    a = db.execute('SELECT start FROM dienst_aktiv WHERE user_id=?', (user_id,)).fetchone()
    if not a:
        return None
    ende = ende or time.time()
    with db:
        db.execute('DELETE FROM dienst_aktiv WHERE user_id=?', (user_id,))
        db.execute('INSERT INTO dienst_log (user_id, start, ende) VALUES (?, ?, ?)', (user_id, a['start'], ende))
    return max(ende - a['start'], 0)

def dienstzeit_panel_embed():
    e = text_embed('dienstzeit_panel_fuehrung')
    rows = db.execute('SELECT user_id, start FROM dienst_aktiv ORDER BY start').fetchall()
    zeilen = [f'<@{r['user_id']}>{nummer_tag(r['user_id'])} – seit {fmt_zeit(r['start'], 'R')}' for r in rows]
    e.add_field(name=field_heading(ui_text('dienstzeit_panel_embed.feld.01', v0=f'{len(rows)}')), value=('\n'.join(zeilen) or '*Niemand ist eingestempelt.*')[:1024], inline=False)
    return e

async def dienstzeit_panel_aktualisieren():
    mid, cid = (setting_get('dz_panel_message'), setting_get('dz_panel_channel'))
    if not mid or not cid:
        return
    kanal = bot.get_channel(int(cid))
    if kanal is None:
        return
    try:
        msg = await kanal.fetch_message(int(mid))
        await msg.edit(embed=dienstzeit_panel_embed())
    except discord.HTTPException:
        pass

async def nummer_sicherstellen(member):
    """Vergibt automatisch eine Nummer, falls noch keine existiert. -> (nummer, neu)"""
    alt = nummer_von(member.id)
    if alt:
        return (alt, False)
    try:
        nummer, _ = nummer_zuweisen(member.id)
    except ValueError:
        return (None, False)
    await nick_setzen(member, nummer)
    await panel_aktualisieren()
    e = text_embed('nummer_zugewiesen', user=member.mention, nummer=nummer)
    await senden(KANAL_DIENSTNUMMER, content=ping(member.mention), embed=e)
    return (nummer, True)

async def nummer_entziehen(guild, user_id, grund):
    nummer = nummer_freigeben(user_id)
    if not nummer:
        return None
    member = guild.get_member(user_id)
    if member:
        await nick_zuruecksetzen(member)
    await panel_aktualisieren()
    msg = await senden(KANAL_DIENSTNUMMER, embed=text_embed('nummer_entzogen', user=f'<@{user_id}>', nummer=nummer, grund=grund), view=AufrueckenView())
    if msg is not None:
        with db:
            db.execute('INSERT OR REPLACE INTO aufrueck_offen (message_id, nummer, erledigt) VALUES (?, ?, 0)', (msg.id, nummer))
    return nummer

async def abgleich(guild):
    """Räumt Nummern auf, deren Besitzer weg sind oder die Hauptrolle nicht mehr haben."""
    if guild.get_role(ROLLE_HAUPT_POLIZEI) is None:
        print('⚠️ Hauptrolle nicht gefunden – Abgleich übersprungen (Sicherheitsabbruch).')
        return
    if not guild.chunked:
        await guild.chunk()
    for r in list(db.execute('SELECT user_id FROM dienstnummern')):
        m = guild.get_member(r['user_id'])
        if m is None:
            await nummer_entziehen(guild, r['user_id'], 'Hat den Server verlassen')
        elif not hat_hauptrolle(m):
            await nummer_entziehen(guild, r['user_id'], 'Hauptrolle nicht mehr vorhanden')
    if AUTO_DIENSTNUMMER and AUTO_VERGABE_BEIM_START:
        for m in guild.members:
            if not m.bot and hat_hauptrolle(m) and (not nummer_von(m.id)):
                await nummer_sicherstellen(m)

def neues_aktenzeichen():
    while True:
        az = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
        if not db.execute('SELECT 1 FROM warns WHERE az=?', (az,)).fetchone():
            return az

async def warn_erstellen(user_id, grund, tage, von_mention, von_id):
    """Legt die Warn an, postet sie und vergibt die Warn-Rolle. -> (az, aktiv, fehler)"""
    jetzt = datetime.datetime.now(datetime.timezone.utc)
    ablauf = jetzt + datetime.timedelta(days=tage)
    az = neues_aktenzeichen()
    with db:
        db.execute('INSERT INTO warns (user_id, grund, von, erstellt, ablauf, az) VALUES (?, ?, ?, ?, ?, ?)', (user_id, grund, von_id, jetzt.timestamp(), ablauf.timestamp(), az))
    aktiv = db.execute('SELECT COUNT(*) c FROM warns WHERE user_id=? AND ablauf>?', (user_id, time.time())).fetchone()['c']
    e = text_embed('disziplinar', user=f'<@{user_id}>', tag=nummer_tag(user_id), grund=grund, az=az, ablauf=discord.utils.format_dt(ablauf, 'F'), dauer=f'{tage}d', aktiv=aktiv, direktion=von_mention)
    await senden(KANAL_WARN, content=ping(f'<@{user_id}>'), embed=e)
    fehler = await warn_rollen_setzen(user_id, f'Warn {az}')
    return (az, aktiv, fehler)

async def warns_ablaufen():
    """Löscht Warns exakt beim Ablauf und entfernt die Warn-Rolle, wenn keine Warn mehr aktiv ist."""
    jetzt = time.time()
    betroffen = [r['user_id'] for r in db.execute('SELECT DISTINCT user_id FROM warns WHERE ablauf<=?', (jetzt,))]
    if not betroffen:
        return
    with db:
        db.execute('DELETE FROM warns WHERE ablauf<=?', (jetzt,))
    for uid in betroffen:
        await warn_rollen_setzen(uid, 'Warn abgelaufen')

async def dienstsperren_ablaufen():
    """Entfernt abgelaufene Dienstsperren samt Rolle."""
    jetzt = time.time()
    rows = db.execute('SELECT user_id FROM dienstsperren WHERE ablauf<=?', (jetzt,)).fetchall()
    if not rows:
        return
    with db:
        db.execute('DELETE FROM dienstsperren WHERE ablauf<=?', (jetzt,))
    g = hauptguild()
    if g is None:
        return
    for r in rows:
        await sonderrolle(g.get_member(r['user_id']), ROLLE_DIENSTSPERRE, False, 'Dienstsperre abgelaufen')

async def auto_ausstempeln():
    if not AUTO_AUSSTEMPELN_NACH_STUNDEN:
        return
    limit = AUTO_AUSSTEMPELN_NACH_STUNDEN * 3600
    rows = db.execute('SELECT user_id, start FROM dienst_aktiv WHERE start<?', (time.time() - limit,)).fetchall()
    for r in rows:
        dauer = dienst_beenden(r['user_id'], ende=r['start'] + limit)
        await senden(dz_log(), embed=text_embed('dienstende_auto', user=f'<@{r['user_id']}>', dauer=dauer_text(dauer or 0), stunden=AUTO_AUSSTEMPELN_NACH_STUNDEN))
    if rows:
        await dienstzeit_panel_aktualisieren()
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

class PolizeiBot(commands.Bot):

    def __init__(self):
        super().__init__(command_prefix='!', intents=intents, tree_cls=SafeCommandTree, allowed_mentions=discord.AllowedMentions(everyone=False, users=MELDUNG_PING, roles=[discord.Object(id=rid) for rid in (ROLLE_ANWALT, ROLLE_HAUPT_POLIZEI, ROLLE_AUSBILDUNG_ABSCHLUSS_PING) if rid]))

    async def close(self):
        for loop in (wartung, checks_pruefen, wochenbericht_loop, cleanup):
            if loop.is_running():
                loop.cancel()
        try:
            await super().close()
        finally:
            db.close()

    async def setup_hook(self):
        self.add_view(AusweisPanelView())
        self.add_view(DienstausweisView())
        self.add_view(AntragView())
        self.add_view(AktivitaetView())
        self.add_view(PlatzverweisView())
        self.add_view(AusbildungView())
        self.add_view(PolizeiDienstzeitView())
        self.add_view(FuehrungDienstzeitView())
        self.add_view(AufrueckenView())
        self.add_view(NummernPanelView())
        self.add_view(AusbildungPanelView())
        self.add_view(DatenbankView())
        if GUILD_ID:
            g = discord.Object(id=GUILD_ID)
            self.tree.copy_global_to(guild=g)
            await self.tree.sync(guild=g)
        else:
            await self.tree.sync()
        print('✅ Slash-Commands synchronisiert.')
        wartung.start()
        checks_pruefen.start()
        wochenbericht_loop.start()
        cleanup.start()
bot = PolizeiBot()

def startup_check():
    probleme = []
    kanaele = {'KANAL_ANWALT': KANAL_ANWALT, 'KANAL_AUSWEIS': KANAL_AUSWEIS, 'KANAL_DIENSTZEIT': KANAL_DIENSTZEIT, 'KANAL_EINSTELLUNG': KANAL_EINSTELLUNG, 'KANAL_BEFOERDERUNG': KANAL_BEFOERDERUNG, 'KANAL_DEGRADIERUNG': KANAL_DEGRADIERUNG, 'KANAL_WARN': KANAL_WARN, 'KANAL_SUSPENDIERUNG': KANAL_SUSPENDIERUNG, 'KANAL_ENTLASSUNG': KANAL_ENTLASSUNG, 'KANAL_SPERREN': KANAL_SPERREN, 'KANAL_BEWERBUNGSSPERRE': KANAL_BEWERBUNGSSPERRE, 'KANAL_DIENSTNUMMER': KANAL_DIENSTNUMMER, 'KANAL_DIENSTNUMMER_PANEL': KANAL_DIENSTNUMMER_PANEL, 'KANAL_WOCHENBERICHT': KANAL_WOCHENBERICHT, 'KANAL_AUSBILDUNG': KANAL_AUSBILDUNG, 'KANAL_DIENSTZEIT_LOG': KANAL_DIENSTZEIT_LOG, 'KANAL_DIENSTZEIT_LOG_FUEHRUNG': KANAL_DIENSTZEIT_LOG_FUEHRUNG}
    for name, kid in kanaele.items():
        if kid and bot.get_channel(kid) is None:
            probleme.append(f'Kanal {name} ({kid}) nicht gefunden')
    guild = hauptguild()
    if guild is None:
        probleme.append('Guild nicht gefunden – Rollenprüfung übersprungen')
    else:
        rollen = {f'Rang {name}': rid for name, rid, _ in TEAMLISTE_RAENGE}
        rollen.update({'ROLLE_ANWALT': ROLLE_ANWALT, 'ROLLE_HAUPT_POLIZEI': ROLLE_HAUPT_POLIZEI, 'ROLLE_AUSBILDUNG_ABSCHLUSS_PING': ROLLE_AUSBILDUNG_ABSCHLUSS_PING, 'ROLLE_WARN_1': ROLLEN_WARN[0], 'ROLLE_WARN_2': ROLLEN_WARN[1], 'ROLLE_WARN_3': ROLLEN_WARN[2], 'ROLLE_DIENSTSPERRE': ROLLE_DIENSTSPERRE, 'ROLLE_SUSPENDIERT': ROLLE_SUSPENDIERT, 'ROLLE_ENTLASSEN': ROLLE_ENTLASSEN})
        for name, rid in rollen.items():
            if rid and guild.get_role(rid) is None:
                probleme.append(f'Rolle {name} ({rid}) nicht gefunden')
    if probleme:
        print('⚠️  STARTUP-CONFIG-PROBLEME:')
        for p in probleme:
            print(f'   • {p}')
        print('   → Bot läuft trotzdem, aber einzelne Features werden fehlschlagen.')
    else:
        print('✅ Startup-Config-Check: alle Kanäle & Rollen vorhanden.')

@tasks.loop(minutes=10)
async def wartung():
    for g in bot.guilds:
        if GUILD_ID and g.id != GUILD_ID:
            continue
        await abgleich(g)
    await panel_aktualisieren()

@tasks.loop(minutes=1)
async def checks_pruefen():
    try:
        await warns_ablaufen()
    except Exception as e:
        print('Warn-Ablauf fehlgeschlagen:', repr(e))
    try:
        await dienstsperren_ablaufen()
    except Exception as e:
        print('Dienstsperren-Ablauf fehlgeschlagen:', repr(e))
    try:
        await auto_ausstempeln()
    except Exception as e:
        print('Auto-Ausstempeln fehlgeschlagen:', repr(e))
    faellig = db.execute('SELECT * FROM aktivitaetschecks WHERE abgeschlossen=0 AND frist<=?', (time.time(),)).fetchall()
    for row in faellig:
        with db:
            db.execute('UPDATE aktivitaetschecks SET abgeschlossen=1 WHERE id=?', (row['id'],))
        try:
            await aktivitaetscheck_auswerten(row)
        except Exception as e:
            print('Aktivitätscheck-Auswertung fehlgeschlagen:', repr(e))

@tasks.loop(time=WOCHENBERICHT_ZEIT)
async def wochenbericht_loop():
    jetzt = datetime.datetime.now(TZ)
    if jetzt.weekday() != WOCHENBERICHT_TAG:
        return
    kw = jetzt.isocalendar()
    key = f'wochenbericht:{kw[0]}-{kw[1]}'
    if setting_get(key):
        return
    if await wochenbericht_senden(KANAL_WOCHENBERICHT or dz_log()):
        setting_set(key, 1)
CLEANUP_LOG_NACH_TAGEN = 180
CLEANUP_ABGELAUFENE_SPERREN = True

@tasks.loop(time=datetime.time(hour=4, minute=0, tzinfo=TZ))
async def cleanup():
    jetzt = time.time()
    with db:
        c_logs = db.execute('DELETE FROM dienst_log WHERE ende < ?', (jetzt - CLEANUP_LOG_NACH_TAGEN * 86400,)).rowcount
        c_sperren = 0
        if CLEANUP_ABGELAUFENE_SPERREN:
            c_sperren = db.execute('DELETE FROM bewerbungssperren WHERE ablauf < ?', (jetzt,)).rowcount
        c_checks = db.execute('DELETE FROM aktivitaetschecks WHERE abgeschlossen=1 AND frist < ?', (jetzt - 30 * 86400,)).rowcount
    print(f'🧹 Cleanup: {c_logs} Dienst-Logs, {c_sperren} Sperren, {c_checks} Checks entfernt.')
for _loop in (wartung, checks_pruefen, wochenbericht_loop, cleanup):

    @_loop.before_loop
    async def _warten():
        await bot.wait_until_ready()

@bot.event
async def on_ready():
    print(f'✅ Eingeloggt als {bot.user}')
    print(f'ℹ️ Bot-Version: v3 (2 Dienstzeit-Panels, Nummern-Panel, Aufrücken) | MELDUNG_PING = {MELDUNG_PING}')
    startup_check()
    await bot.change_presence(activity=discord.Game(name=f'Notruf 110 | {BRANDING_NAME}'))

@bot.tree.error
async def tree_fehler(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.CheckFailure):
        text = '❌ Dafür hast du keine Berechtigung.'
    else:
        text = '❌ Unerwarteter Fehler. Bitte melde das der Bot-Verwaltung.'
        logging.getLogger('polizei.commands').error('Command fehlgeschlagen', exc_info=(type(error), error, error.__traceback__))
    try:
        if interaction.response.is_done():
            await send_with_branding(interaction.followup.send, text, ephemeral=True)
        else:
            await send_with_branding(interaction.response.send_message, text, ephemeral=True)
    except discord.HTTPException:
        pass

@bot.event
async def on_member_update(before: discord.Member, after: discord.Member):
    if GUILD_ID and after.guild.id != GUILD_ID:
        return
    if before.roles == after.roles:
        return
    hatte, hat = (hat_hauptrolle(before), hat_hauptrolle(after))
    if not hatte and hat and AUTO_DIENSTNUMMER:
        await nummer_sicherstellen(after)
    elif hatte and (not hat):
        if dienst_beenden(after.id) is not None:
            await dienstzeit_panel_aktualisieren()
        await nummer_entziehen(after.guild, after.id, 'Hauptrolle entfernt')

@bot.event
async def on_member_remove(member: discord.Member):
    if GUILD_ID and member.guild.id != GUILD_ID:
        return
    if dienst_beenden(member.id) is not None:
        await dienstzeit_panel_aktualisieren()
    await nummer_entziehen(member.guild, member.id, 'Hat den Server verlassen')
anwalt_cooldowns = {}

@bot.event
async def on_message(message: discord.Message):
    if message.author.bot or not message.guild:
        return
    if message.channel.id == KANAL_ANWALT and 'anwalt' in message.content.lower():
        jetzt = time.time()
        frei_ab = anwalt_cooldowns.get(message.author.id, 0)
        if frei_ab > jetzt:
            rest_min = (int(frei_ab - jetzt) + 59) // 60
            await send_with_branding(message.reply, ui_text('on_message.antwort.01', v0=f'{rest_min}'), delete_after=10)
            return
        anwalt_cooldowns[message.author.id] = jetzt + 15 * 60
        e = text_embed('anwalt_ruf', user=message.author.mention, rolle=f'<@&{ROLLE_ANWALT}>')
        await send_with_branding(message.reply, content=ui_text('on_message.antwort.02', v0=f'{ROLLE_ANWALT}'), embed=e)
        try:
            await message.delete()
        except discord.HTTPException:
            pass

@bot.tree.command(name='anwalt_panel', description='Postet das Anwalt-Infopanel (Nur Admins)')
@app_commands.default_permissions(administrator=True)
@app_commands.checks.has_permissions(administrator=True)
async def anwalt_panel(interaction: discord.Interaction):
    await send_with_branding(interaction.response.send_message, ui_text('anwalt_panel.antwort.01'), ephemeral=True)
    await send_with_branding(interaction.channel.send, embed=text_embed('anwalt_panel', rolle=f'<@&{ROLLE_ANWALT}>'))

@bot.tree.command(name='hilfe', description='Zeigt alle Befehle, die du nutzen kannst')
async def hilfe(interaction: discord.Interaction):
    e = basis_embed(ui_text('hilfe.titel.01', v0=f'{BRANDING_NAME}'), ui_text('hilfe.text.02'), 255)
    for titel, stufe, eintraege in HILFE:
        if stufe == 'fuehrung' and (not ist_fuehrung_member(interaction.user)):
            continue
        if stufe == 'ausbilder' and (not ist_ausbilder_member(interaction.user)):
            continue
        e.add_field(name=field_heading(titel), value='\n'.join((f'`{c}` – {d}' for c, d in eintraege))[:1024], inline=False)
    await send_with_branding(interaction.response.send_message, embed=e, ephemeral=True)

@bot.tree.command(name='teamliste', description='Erstellt eine aktuelle Teamliste')
async def teamliste(interaction: discord.Interaction):
    await interaction.response.defer()
    guild = interaction.guild
    abschnitte = []
    for name, rid, _ in TEAMLISTE_RAENGE:
        rolle = guild.get_role(rid)
        if rolle:
            m = ', '.join((x.mention for x in rolle.members)) or '*Aktuell niemand*'
        else:
            m = '*Rolle nicht gefunden*'
        abschnitte.append(f'**{name}:**\n{m}\n')
    seiten, aktuell = ([], '')
    for a in abschnitte:
        if len(aktuell) + len(a) > 3800:
            seiten.append(aktuell)
            aktuell = ''
        aktuell += a + '\n'
    if aktuell:
        seiten.append(aktuell)
    embeds = []
    for i, s in enumerate(seiten[:10]):
        e = basis_embed(f'👮\u200d♂️ Teamliste | {BRANDING_NAME}' if i == 0 else None, s, 255)
        if i == 0 and guild.icon:
            e.set_thumbnail(url=guild.icon.url)
        embeds.append(e)
    await send_with_branding(interaction.followup.send, embeds=embeds)

async def rang_pruefen(interaction, user, rang):
    if user.bot:
        await send_with_branding(interaction.followup.send, ui_text('rang_pruefen.antwort.01'), ephemeral=True)
        return None
    info = RANG_INFO.get(rang.id)
    if not info:
        await send_with_branding(interaction.followup.send, ui_text('rang_pruefen.antwort.02'), ephemeral=True)
        return None
    return info

async def rangwechsel(interaction, user, rang, grund, key, kanal_id):
    await interaction.response.defer(ephemeral=True)
    info = await rang_pruefen(interaction, user, rang)
    if not info:
        return
    gruppe = info[1]
    alte = [r for r in user.roles if RANG_INFO.get(r.id, (None, None))[1] == gruppe and r.id != rang.id]
    add = [rang]
    haupt = interaction.guild.get_role(ROLLE_HAUPT_POLIZEI)
    if haupt and haupt not in user.roles:
        add.append(haupt)
    fehler = await rollen_aendern(user, add=add, remove=alte, grund=f'{TEXTE.get(key, {}).get('titel', key)} durch {interaction.user}')
    if fehler:
        return await send_with_branding(interaction.followup.send, ui_text('rangwechsel.antwort.01', v0=f'{fehler}'), ephemeral=True)
    e = text_embed(key, user=user.mention, tag=nummer_tag(user.id), rang=rang.mention, alterrang=', '.join((r.mention for r in alte)) or '–', grund=grund, direktion=interaction.user.mention)
    sent = await senden(kanal_id, content=ping(user.mention), embed=e)
    if sent is None:
        return await send_with_branding(interaction.followup.send, ui_text('rangwechsel.antwort.02'), ephemeral=True)
    await send_with_branding(interaction.followup.send, ui_text('rangwechsel.antwort.03'), ephemeral=True)

@bot.tree.command(name='befoerderung', description='Befördert einen Beamten')
@ist_fuehrung()
async def befoerderung(interaction: discord.Interaction, user: discord.Member, rang: discord.Role, begruendung: str='Ausbildung bestanden'):
    await rangwechsel(interaction, user, rang, begruendung, 'befoerderung', KANAL_BEFOERDERUNG)

@bot.tree.command(name='degradierung', description='Degradiert einen Beamten')
@ist_fuehrung()
async def degradierung(interaction: discord.Interaction, user: discord.Member, rang: discord.Role, begruendung: str='Eigenwunsch'):
    await rangwechsel(interaction, user, rang, begruendung, 'degradierung', KANAL_DEGRADIERUNG)

@bot.tree.command(name='einstellung', description='Stellt einen neuen Beamten ein')
@ist_fuehrung()
async def einstellung(interaction: discord.Interaction, user: discord.Member, rang: discord.Role, notiz: str='Keine'):
    await interaction.response.defer(ephemeral=True)
    info = await rang_pruefen(interaction, user, rang)
    if not info:
        return
    add = [rang]
    haupt = interaction.guild.get_role(ROLLE_HAUPT_POLIZEI)
    if haupt and haupt not in user.roles:
        add.append(haupt)
    fehler = await rollen_aendern(user, add=add, grund=f'Einstellung durch {interaction.user}')
    if fehler:
        return await send_with_branding(interaction.followup.send, ui_text('einstellung.antwort.01', v0=f'{fehler}'), ephemeral=True)
    hinweis = ''
    f2 = await sonderrolle(user, ROLLE_ENTLASSEN, False, 'Neueinstellung')
    if f2:
        hinweis = f'\n⚠️ Entlassen-Rolle konnte nicht entfernt werden: {f2}'
    if AUTO_DIENSTNUMMER:
        await nummer_sicherstellen(user)
    e = text_embed('einstellung', user=user.mention, tag=nummer_tag(user.id), rang=rang.mention, notiz=notiz, direktion=interaction.user.mention)
    await senden(KANAL_EINSTELLUNG, content=ping(user.mention), embed=e)
    await send_with_branding(interaction.followup.send, '✅ Eingestellt, Rollen vergeben & Meldung gepostet.' + hinweis, ephemeral=True)

@bot.tree.command(name='entlassung', description='Entlässt einen Beamten')
@ist_fuehrung()
async def entlassung(interaction: discord.Interaction, user: discord.Member, grund: str):
    await interaction.response.defer(ephemeral=True)
    if not await confirm_action_local(interaction, f'Entlassung von {user.display_name} bestätigen?\nGrund: {grund}'):
        return
    actor = await interaction.guild.fetch_member(interaction.user.id)
    if not ist_fuehrung_member(actor):
        return await send_with_branding(interaction.followup.send, ui_text('entlassung.antwort.01'), ephemeral=True)
    user = await interaction.guild.fetch_member(user.id)
    if user.bot:
        return await send_with_branding(interaction.followup.send, ui_text('entlassung.antwort.02'), ephemeral=True)
    entfernen = [r for r in user.roles if r.id in RANG_INFO or r.id == ROLLE_HAUPT_POLIZEI]
    fehler = await rollen_aendern(user, remove=entfernen, grund=f'Entlassung durch {interaction.user}')
    if fehler:
        return await send_with_branding(interaction.followup.send, ui_text('entlassung.antwort.03', v0=f'{fehler}'), ephemeral=True)
    nummer = nummer_von(user.id)
    tag = f' [{nummer}]' if nummer else ''
    await nummer_entziehen(interaction.guild, user.id, 'Entlassung')
    if dienst_beenden(user.id) is not None:
        await dienstzeit_panel_aktualisieren()
    with db:
        db.execute('DELETE FROM suspendierungen WHERE user_id=?', (user.id,))
        db.execute('DELETE FROM dienstsperren WHERE user_id=?', (user.id,))
    hinweise = []
    sonder = [(ROLLE_SUSPENDIERT, False, 'Suspendiert-Rolle'), (ROLLE_DIENSTSPERRE, False, 'Dienstsperre-Rolle')]
    sonder += [(rid, False, 'Warn-Rolle') for rid in ROLLEN_WARN]
    sonder.append((ROLLE_ENTLASSEN, True, 'Entlassen-Rolle'))
    for rid, geben, art in sonder:
        f = await sonderrolle(user, rid, geben, f'Entlassung durch {interaction.user}')
        if f:
            hinweise.append(f'⚠️ {art}: {f}')
    e = text_embed('entlassung', user=user.mention, tag=tag, grund=grund, nummer=nummer or '-', direktion=interaction.user.mention)
    await senden(KANAL_ENTLASSUNG, content=ping(user.mention), embed=e)
    await send_with_branding(interaction.followup.send, '✅ Rollen entfernt, Nummer freigegeben & Meldung gepostet.' + ('\n' + '\n'.join(hinweise) if hinweise else ''), ephemeral=True)

@bot.tree.command(name='warn', description='Leitet eine Disziplinarmaßnahme (Dienst-Warn) ein')
@ist_fuehrung()
async def warn(interaction: discord.Interaction, user: discord.Member, grund: str, dauer_tage: app_commands.Range[int, 1, 365]=7):
    await interaction.response.defer(ephemeral=True)
    az, _, fehler = await warn_erstellen(user.id, grund, dauer_tage, interaction.user.mention, interaction.user.id)
    hinweis = f'\n⚠️ Warn-Rolle konnte nicht vergeben werden: {fehler}' if fehler else ''
    await send_with_branding(interaction.followup.send, ui_text('warn.antwort.01', v0=f'{az}', v1=f'{hinweis}'), ephemeral=True)

@bot.tree.command(name='warns', description='Zeigt die aktiven Warns eines Beamten')
@ist_fuehrung()
async def warns(interaction: discord.Interaction, user: discord.Member):
    rows = db.execute('SELECT * FROM warns WHERE user_id=? AND ablauf>? ORDER BY id', (user.id, time.time())).fetchall()
    if not rows:
        return await send_with_branding(interaction.response.send_message, ui_text('warns.antwort.01', v0=f'{user.mention}'), ephemeral=True)
    zeilen = [f'`{r['az'] or '#' + str(r['id'])}` – {r['grund']} (bis {fmt_zeit(r['ablauf'], 'F')})' for r in rows]
    await send_with_branding(interaction.response.send_message, embed=basis_embed(ui_text('warns.titel.02', v0=f'{user.display_name}'), '\n'.join(zeilen)[:4000], 16753920), ephemeral=True)

@bot.tree.command(name='warn_entfernen', description='Entfernt eine Warn anhand des Aktenzeichens')
@ist_fuehrung()
async def warn_entfernen(interaction: discord.Interaction, aktenzeichen: str):
    await interaction.response.defer(ephemeral=True)
    az = aktenzeichen.strip().upper()
    row = db.execute('SELECT user_id FROM warns WHERE az=?', (az,)).fetchone()
    if not row:
        return await send_with_branding(interaction.followup.send, ui_text('warn_entfernen.antwort.01'), ephemeral=True)
    with db:
        db.execute('DELETE FROM warns WHERE az=?', (az,))
    f = await warn_rollen_setzen(row['user_id'], f'Warn {az} entfernt')
    hinweis = f'\n⚠️ Warn-Rolle konnte nicht angepasst werden: {f}' if f else ''
    await send_with_branding(interaction.followup.send, f'✅ `{az}` entfernt.' + hinweis, ephemeral=True)

@bot.tree.command(name='suspendierung', description='Suspendiert einen Beamten')
@ist_fuehrung()
async def suspendierung(interaction: discord.Interaction, user: discord.Member, grund: str):
    await interaction.response.defer(ephemeral=True)
    with db:
        db.execute('INSERT INTO suspendierungen (user_id, grund, von, seit) VALUES (?, ?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET grund=excluded.grund, von=excluded.von, seit=excluded.seit', (user.id, grund, interaction.user.id, time.time()))
    if dienst_beenden(user.id) is not None:
        await dienstzeit_panel_aktualisieren()
    fehler = await sonderrolle(user, ROLLE_SUSPENDIERT, True, f'Suspendierung durch {interaction.user}')
    e = text_embed('suspendierung', user=user.mention, tag=nummer_tag(user.id), grund=grund, direktion=interaction.user.mention)
    await senden(KANAL_SUSPENDIERUNG, content=ping(user.mention), embed=e)
    hinweis = f'\n⚠️ Suspendiert-Rolle konnte nicht vergeben werden: {fehler}' if fehler else ''
    await send_with_branding(interaction.followup.send, '✅ Suspendierung gepostet. Einstempeln ist für den Beamten gesperrt.' + hinweis, ephemeral=True)

@bot.tree.command(name='suspendierung_aufheben', description='Hebt eine Suspendierung auf')
@ist_fuehrung()
async def suspendierung_aufheben(interaction: discord.Interaction, user: discord.Member):
    await interaction.response.defer(ephemeral=True)
    with db:
        c = db.execute('DELETE FROM suspendierungen WHERE user_id=?', (user.id,))
    fehler = await sonderrolle(user, ROLLE_SUSPENDIERT, False, f'Suspendierung aufgehoben durch {interaction.user}')
    if not c.rowcount and (not ROLLE_SUSPENDIERT):
        return await send_with_branding(interaction.followup.send, ui_text('suspendierung_aufheben.antwort.01'), ephemeral=True)
    e = text_embed('suspendierung_aufgehoben', user=user.mention, tag=nummer_tag(user.id), direktion=interaction.user.mention)
    await senden(KANAL_SUSPENDIERUNG, content=ping(user.mention), embed=e)
    hinweis = f'\n⚠️ Rolle konnte nicht entfernt werden: {fehler}' if fehler else ''
    await send_with_branding(interaction.followup.send, '✅ Suspendierung aufgehoben.' + hinweis, ephemeral=True)

@bot.tree.command(name='dienstsperre', description='Verhängt eine Dienst-Sperre')
@ist_fuehrung()
async def dienstsperre(interaction: discord.Interaction, user: discord.Member, grund: str, dauer_tage: app_commands.Range[int, 1, 365]=7):
    await interaction.response.defer(ephemeral=True)
    ablauf = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=dauer_tage)
    with db:
        db.execute('INSERT INTO dienstsperren (user_id, grund, von, ablauf) VALUES (?, ?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET grund=excluded.grund, von=excluded.von, ablauf=excluded.ablauf', (user.id, grund, interaction.user.id, ablauf.timestamp()))
    if dienst_beenden(user.id) is not None:
        await dienstzeit_panel_aktualisieren()
    fehler = await sonderrolle(user, ROLLE_DIENSTSPERRE, True, f'Dienstsperre durch {interaction.user}')
    e = text_embed('dienstsperre', user=user.mention, tag=nummer_tag(user.id), grund=grund, dauer=f'{dauer_tage}d', ablauf=discord.utils.format_dt(ablauf, 'F'), direktion=interaction.user.mention)
    await senden(KANAL_SPERREN, content=ping(user.mention), embed=e)
    hinweis = f'\n⚠️ Dienstsperre-Rolle konnte nicht vergeben werden: {fehler}' if fehler else ''
    await send_with_branding(interaction.followup.send, '✅ Sperre gepostet. Einstempeln ist bis zum Ablauf gesperrt.' + hinweis, ephemeral=True)

@bot.tree.command(name='dienstsperre_aufheben', description='Hebt eine Dienstsperre vorzeitig auf')
@ist_fuehrung()
async def dienstsperre_aufheben(interaction: discord.Interaction, user: discord.Member):
    await interaction.response.defer(ephemeral=True)
    with db:
        c = db.execute('DELETE FROM dienstsperren WHERE user_id=?', (user.id,))
    fehler = await sonderrolle(user, ROLLE_DIENSTSPERRE, False, f'Dienstsperre aufgehoben durch {interaction.user}')
    if not c.rowcount and (not fehler):
        return await send_with_branding(interaction.followup.send, ui_text('dienstsperre_aufheben.antwort.01'), ephemeral=True)
    hinweis = f'\n⚠️ Rolle konnte nicht entfernt werden: {fehler}' if fehler else ''
    await send_with_branding(interaction.followup.send, '✅ Dienstsperre aufgehoben.' + hinweis, ephemeral=True)

@bot.tree.command(name='bewerbungssperre', description='Verhängt eine Bewerbungssperre für einen Nutzer')
@ist_fuehrung()
async def bewerbungssperre(interaction: discord.Interaction, user: discord.User, grund: str, dauer_tage: app_commands.Range[int, 1, 365]=7):
    await interaction.response.defer(ephemeral=True)
    ablauf = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=dauer_tage)
    with db:
        db.execute('INSERT INTO bewerbungssperren (user_id, grund, ablauf, von) VALUES (?, ?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET grund=excluded.grund, ablauf=excluded.ablauf, von=excluded.von', (user.id, grund, ablauf.timestamp(), interaction.user.id))
    e = text_embed('bewerbungssperre', user=user.mention, grund=grund, dauer=f'{dauer_tage}d', ablauf=discord.utils.format_dt(ablauf, 'F'), direktion=interaction.user.mention)
    await senden(KANAL_BEWERBUNGSSPERRE, content=ping(user.mention), embed=e)
    await send_with_branding(interaction.followup.send, ui_text('bewerbungssperre.antwort.01'), ephemeral=True)

@bot.tree.command(name='bewerbungssperre_pruefen', description='Prüft, ob ein Nutzer gerade bewerbungsgesperrt ist')
@ist_fuehrung()
async def bewerbungssperre_pruefen(interaction: discord.Interaction, user: discord.User):
    r = db.execute('SELECT * FROM bewerbungssperren WHERE user_id=? AND ablauf>?', (user.id, time.time())).fetchone()
    text = f'⛔ {user.mention} ist gesperrt bis {fmt_zeit(r['ablauf'])}.\n**Grund:** {r['grund']}' if r else f'✅ {user.mention} hat keine aktive Bewerbungssperre.'
    await send_with_branding(interaction.response.send_message, text, ephemeral=True)

async def _dienstzeit_aktion(interaction: discord.Interaction, aktion: str, fuehrung: bool=False):
    if fuehrung and (not ist_fuehrung_member(interaction.user)):
        return await send_with_branding(interaction.response.send_message, ui_text('_dienstzeit_aktion.antwort.01'), ephemeral=True)
    if not hat_hauptrolle(interaction.user) and (not ist_fuehrung_member(interaction.user)):
        return await send_with_branding(interaction.response.send_message, ui_text('_dienstzeit_aktion.antwort.02'), ephemeral=True)
    uid = interaction.user.id
    if aktion == 'ein':
        if db.execute('SELECT 1 FROM suspendierungen WHERE user_id=?', (uid,)).fetchone():
            return await send_with_branding(interaction.response.send_message, ui_text('_dienstzeit_aktion.antwort.03'), ephemeral=True)
        sperre = db.execute('SELECT ablauf FROM dienstsperren WHERE user_id=? AND ablauf>?', (uid, time.time())).fetchone()
        if sperre:
            return await send_with_branding(interaction.response.send_message, ui_text('_dienstzeit_aktion.antwort.04', v0=f'{fmt_zeit(sperre['ablauf'])}'), ephemeral=True)
        if db.execute('SELECT 1 FROM dienst_aktiv WHERE user_id=?', (uid,)).fetchone():
            return await send_with_branding(interaction.response.send_message, ui_text('_dienstzeit_aktion.antwort.05'), ephemeral=True)
        with db:
            db.execute('INSERT INTO dienst_aktiv (user_id, start) VALUES (?, ?)', (uid, time.time()))
        e = text_embed('dienstbeginn', user=interaction.user.mention)
    else:
        dauer = dienst_beenden(uid)
        if dauer is None:
            return await send_with_branding(interaction.response.send_message, ui_text('_dienstzeit_aktion.antwort.06'), ephemeral=True)
        e = text_embed('dienstende', user=interaction.user.mention, dauer=dauer_text(dauer))
    await interaction.response.defer(ephemeral=True)
    await senden(dz_log(fuehrung), embed=e)
    await send_with_branding(interaction.followup.send, ui_text('_dienstzeit_aktion.antwort.07'), ephemeral=True)
    await dienstzeit_panel_aktualisieren()

async def _dienstzeit_info_anzeigen(interaction: discord.Interaction, user: discord.Member):
    if user.id != interaction.user.id and (not ist_fuehrung_member(interaction.user)):
        return await send_with_branding(interaction.response.send_message, ui_text('_dienstzeit_info_anzeigen.antwort.01'), ephemeral=True)
    jetzt = time.time()
    e = basis_embed(ui_text('_dienstzeit_info_anzeigen.titel.02', v0=f'{user.display_name}'), farbe=255)
    e.add_field(name=field_heading(ui_text('_dienstzeit_info_anzeigen.feld.03')), value=dauer_text(dienstzeit_summe(user.id, jetzt - 7 * 86400)))
    e.add_field(name=field_heading(ui_text('_dienstzeit_info_anzeigen.feld.04')), value=dauer_text(dienstzeit_summe(user.id, jetzt - 30 * 86400)))
    await send_with_branding(interaction.response.send_message, embed=e, ephemeral=True)

@bot.tree.command(name='dienstzeit', description='Stempelt dich in den Dienst ein oder aus')
@app_commands.choices(aktion=[app_commands.Choice(name='Einstempeln (Dienstbeginn)', value='ein'), app_commands.Choice(name='Ausstempeln (Dienstende)', value='aus')])
async def dienstzeit(interaction: discord.Interaction, aktion: app_commands.Choice[str]):
    await _dienstzeit_aktion(interaction, aktion.value)

@bot.tree.command(name='dienstzeit_info', description='Zeigt die Dienstzeit der letzten 7 und 30 Tage')
async def dienstzeit_info(interaction: discord.Interaction, user: discord.Member=None):
    await _dienstzeit_info_anzeigen(interaction, user or interaction.user)

class PolizeiDienstzeitView(SafeView):
    """Panel für Polizisten: nur Ein- und Ausstempeln."""

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label=ui_text('ein.label.01'), style=discord.ButtonStyle.success, emoji='🟢', custom_id='polizei:dzp:ein')
    async def ein(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _dienstzeit_aktion(interaction, 'ein')

    @discord.ui.button(label=ui_text('aus.label.01'), style=discord.ButtonStyle.danger, emoji='🔴', custom_id='polizei:dzp:aus')
    async def aus(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _dienstzeit_aktion(interaction, 'aus')

class BeamterWaehlenView(SafeView):

    def __init__(self, modus):
        super().__init__(timeout=120)
        self.modus = modus

    @discord.ui.select(cls=discord.ui.UserSelect, placeholder=ui_text('auswahl.placeholder.05'), min_values=1, max_values=1)
    async def auswahl(self, interaction: discord.Interaction, select: discord.ui.UserSelect):
        if not ist_fuehrung_member(interaction.user):
            return await send_with_branding(interaction.response.send_message, ui_text('auswahl.antwort.01'), ephemeral=True)
        member = select.values[0]
        if not isinstance(member, discord.Member):
            member = interaction.guild.get_member(member.id)
        if member is None or member.bot:
            return await send_with_branding(interaction.response.send_message, ui_text('auswahl.antwort.02'), ephemeral=True)
        if self.modus == 'info':
            return await _dienstzeit_info_anzeigen(interaction, member)
        dauer = dienst_beenden(member.id)
        if dauer is None:
            return await send_with_branding(interaction.response.send_message, ui_text('auswahl.antwort.03'), ephemeral=True)
        await senden(dz_log(), embed=text_embed('dienstende_fuehrung', user=member.mention, dauer=dauer_text(dauer), direktion=interaction.user.mention))
        await send_with_branding(interaction.response.send_message, ui_text('auswahl.antwort.04'), ephemeral=True)
        await dienstzeit_panel_aktualisieren()

class FuehrungDienstzeitView(SafeView):
    """Panel für die Führungsebene: eigener Dienst + Verwaltung."""

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label=ui_text('ein.label.02'), style=discord.ButtonStyle.success, emoji='🟢', custom_id='polizei:dzf:ein')
    async def ein(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _dienstzeit_aktion(interaction, 'ein', fuehrung=True)

    @discord.ui.button(label=ui_text('aus.label.02'), style=discord.ButtonStyle.danger, emoji='🔴', custom_id='polizei:dzf:aus')
    async def aus(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _dienstzeit_aktion(interaction, 'aus', fuehrung=True)

    @discord.ui.button(label=ui_text('meine.label.02'), style=discord.ButtonStyle.secondary, emoji='⏱️', custom_id='polizei:dzf:info')
    async def meine(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not ist_fuehrung_member(interaction.user):
            return await send_with_branding(interaction.response.send_message, ui_text('meine.antwort.01'), ephemeral=True)
        await _dienstzeit_info_anzeigen(interaction, interaction.user)

    @discord.ui.button(label=ui_text('beamter.label.03'), style=discord.ButtonStyle.secondary, emoji='📊', custom_id='polizei:dzf:beamter')
    async def beamter(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not ist_fuehrung_member(interaction.user):
            return await send_with_branding(interaction.response.send_message, ui_text('beamter.antwort.01'), ephemeral=True)
        await send_with_branding(interaction.response.send_message, ui_text('beamter.antwort.02'), view=BeamterWaehlenView('info'), ephemeral=True)

    @discord.ui.button(label=ui_text('ausstempeln.label.03'), style=discord.ButtonStyle.secondary, emoji='⏹️', custom_id='polizei:dzf:ausstempeln')
    async def ausstempeln(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not ist_fuehrung_member(interaction.user):
            return await send_with_branding(interaction.response.send_message, ui_text('ausstempeln.antwort.01'), ephemeral=True)
        await send_with_branding(interaction.response.send_message, ui_text('ausstempeln.antwort.02'), view=BeamterWaehlenView('aus'), ephemeral=True)

@bot.tree.command(name='dienstzeit_panel', description='Erstellt das Dienstzeit-Panel für Polizisten (Nur Admins)')
@app_commands.default_permissions(administrator=True)
@app_commands.checks.has_permissions(administrator=True)
async def dienstzeit_panel(interaction: discord.Interaction):
    await send_with_branding(interaction.response.send_message, ui_text('dienstzeit_panel.antwort.01'), ephemeral=True)
    await send_with_branding(interaction.channel.send, embed=text_embed('dienstzeit_panel'), view=PolizeiDienstzeitView())

@bot.tree.command(name='dienstzeit_panel_fuehrung', description='Erstellt das Dienstzeit-Panel für die Führung mit Live-Liste (Nur Admins)')
@app_commands.default_permissions(administrator=True)
@app_commands.checks.has_permissions(administrator=True)
async def dienstzeit_panel_fuehrung(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    try:
        msg = await send_with_branding(interaction.channel.send, embed=dienstzeit_panel_embed(), view=FuehrungDienstzeitView())
    except discord.HTTPException:
        return await send_with_branding(interaction.followup.send, ui_text('dienstzeit_panel_fuehrung.antwort.01'), ephemeral=True)
    setting_set('dz_panel_message', msg.id)
    setting_set('dz_panel_channel', msg.channel.id)
    await send_with_branding(interaction.followup.send, ui_text('dienstzeit_panel_fuehrung.antwort.02'), ephemeral=True)

async def wochenbericht_senden(kanal_id):
    kanal = bot.get_channel(kanal_id)
    if kanal is None:
        return False
    guild = kanal.guild
    rolle = guild.get_role(ROLLE_HAUPT_POLIZEI)
    if rolle is None:
        return False
    jetzt = time.time()
    seit = jetzt - 7 * 86400
    eintraege = sorted(((dienstzeit_summe(m.id, seit), m) for m in rolle.members if not m.bot), key=lambda x: -x[0])
    soll = WOCHENSOLL_STUNDEN * 3600
    medaillen = ['🥇', '🥈', '🥉']
    zeilen = []
    for i, (sek, m) in enumerate([x for x in eintraege if x[0] > 0][:15]):
        prefix = medaillen[i] if i < 3 else f'**{i + 1}.**'
        zeilen.append(f'{prefix} {m.mention}{nummer_tag(m.id)} – {dauer_text(sek)}')
    unter = [m.mention for sek, m in eintraege if sek < soll]
    e = text_embed('wochenbericht', von=fmt_zeit(seit, 'd'), bis=fmt_zeit(jetzt, 'd'), gesamt=dauer_text(sum((s for s, _ in eintraege))), anzahl=len(eintraege), soll=f'{WOCHENSOLL_STUNDEN:g}h')
    e.add_field(name=field_heading(ui_text('wochenbericht_senden.feld.01')), value=('\n'.join(zeilen) or '*Keine Dienstzeiten erfasst*')[:1024], inline=False)
    if unter:
        for i, block in enumerate(chunk_text(unter)[:5]):
            e.add_field(name=field_heading(f'⚠️ Unter Mindestsoll ({WOCHENSOLL_STUNDEN:g}h)' if i == 0 else '\u200b'), value=block, inline=False)
    else:
        e.add_field(name=field_heading(ui_text('wochenbericht_senden.feld.02')), value=ui_text('wochenbericht_senden.feldwert.03'), inline=False)
    try:
        await send_with_branding(kanal.send, embed=e)
    except discord.HTTPException as err:
        print('Wochenbericht konnte nicht gesendet werden:', err)
        return False
    return True

@bot.tree.command(name='wochenbericht', description='Postet den Wochenbericht sofort (Führungsebene)')
@ist_fuehrung()
async def wochenbericht(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    ok = await wochenbericht_senden(KANAL_WOCHENBERICHT or dz_log())
    await send_with_branding(interaction.followup.send, '✅ Wochenbericht gepostet.' if ok else '❌ Kanal oder Beamten-Rolle nicht gefunden.', ephemeral=True)

async def aktivitaetscheck_auswerten(row):
    kanal = bot.get_channel(row['channel_id'])
    if kanal is None:
        return
    guild = kanal.guild
    rolle = guild.get_role(ROLLE_HAUPT_POLIZEI)
    mitglieder = [m for m in rolle.members if not m.bot] if rolle else []
    bestaetigt = {r['user_id'] for r in db.execute('SELECT user_id FROM aktivitaet_bestaetigt WHERE check_id=?', (row['id'],))}
    fehlen = [m for m in mitglieder if m.id not in bestaetigt]
    warn_info = ''
    if AKTIVITAETSCHECK_AUTO_WARN and fehlen:
        for m in fehlen:
            await warn_erstellen(m.id, 'Aktivitätscheck nicht bestätigt', AKTIVITAETSCHECK_WARN_TAGE, bot.user.mention, bot.user.id)
        warn_info = f'⚠️ **{len(fehlen)}** Warn(s) wurden automatisch vergeben.'
    try:
        msg = await kanal.fetch_message(row['message_id'])
        await msg.edit(view=None)
    except discord.HTTPException:
        msg = None
    e = text_embed('aktivitaet_ergebnis', anzahl_ok=len(bestaetigt & {m.id for m in mitglieder}), anzahl_fehlt=len(fehlen), warn_info=warn_info)
    if fehlen:
        for i, block in enumerate(chunk_text([m.mention for m in fehlen])[:5]):
            e.add_field(name=field_heading('Nicht bestätigt' if i == 0 else '\u200b'), value=block, inline=False)
    try:
        if msg:
            await send_with_branding(msg.reply, embed=e)
        else:
            await send_with_branding(kanal.send, embed=e)
    except discord.HTTPException:
        pass

class AktivitaetView(SafeView):

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label=ui_text('bestaetigen.label.05'), style=discord.ButtonStyle.success, emoji='✅', custom_id='polizei:akt:ok')
    async def bestaetigen(self, interaction: discord.Interaction, button: discord.ui.Button):
        row = db.execute('SELECT * FROM aktivitaetschecks WHERE message_id=?', (interaction.message.id,)).fetchone()
        if not row or row['abgeschlossen'] or row['frist'] <= time.time():
            return await send_with_branding(interaction.response.send_message, ui_text('bestaetigen.antwort.01'), ephemeral=True)
        if not hat_hauptrolle(interaction.user) and (not ist_fuehrung_member(interaction.user)):
            return await send_with_branding(interaction.response.send_message, ui_text('bestaetigen.antwort.02'), ephemeral=True)
        if db.execute('SELECT 1 FROM aktivitaet_bestaetigt WHERE check_id=? AND user_id=?', (row['id'], interaction.user.id)).fetchone():
            return await send_with_branding(interaction.response.send_message, ui_text('bestaetigen.antwort.03'), ephemeral=True)
        with db:
            db.execute('INSERT INTO aktivitaet_bestaetigt (check_id, user_id) VALUES (?, ?)', (row['id'], interaction.user.id))
        await send_with_branding(interaction.response.send_message, ui_text('bestaetigen.antwort.04'), ephemeral=True)

    @discord.ui.button(label=ui_text('liste.label.05'), style=discord.ButtonStyle.secondary, emoji='📋', custom_id='polizei:akt:liste')
    async def liste(self, interaction: discord.Interaction, button: discord.ui.Button):
        row = db.execute('SELECT * FROM aktivitaetschecks WHERE message_id=?', (interaction.message.id,)).fetchone()
        if not row:
            return await send_with_branding(interaction.response.send_message, ui_text('liste.antwort.01'), ephemeral=True)
        ids = [r['user_id'] for r in db.execute('SELECT user_id FROM aktivitaet_bestaetigt WHERE check_id=?', (row['id'],))]
        e = basis_embed(ui_text('liste.titel.02'), farbe=255)
        e.add_field(name=field_heading(ui_text('liste.feld.03', v0=f'{len(ids)}')), value=(', '.join((f'<@{i}>' for i in ids)) or '*Noch niemand*')[:1024], inline=False)
        if ist_fuehrung_member(interaction.user):
            rolle = interaction.guild.get_role(ROLLE_HAUPT_POLIZEI)
            offen = [m.mention for m in (rolle.members if rolle else []) if not m.bot and m.id not in ids]
            e.add_field(name=field_heading(ui_text('liste.feld.04', v0=f'{len(offen)}')), value=(', '.join(offen) or '*Niemand*')[:1024], inline=False)
        await send_with_branding(interaction.response.send_message, embed=e, ephemeral=True)

@bot.tree.command(name='aktivitaetscheck', description='Startet einen Aktivitätscheck mit Frist (Führungsebene)')
@ist_fuehrung()
async def aktivitaetscheck(interaction: discord.Interaction, stunden: app_commands.Range[int, 1, 168]=24):
    await interaction.response.defer(ephemeral=True)
    frist = time.time() + stunden * 3600
    e = text_embed('aktivitaetscheck', frist=fmt_zeit(frist, 'F'), relativ=fmt_zeit(frist, 'R'))
    try:
        msg = await send_with_branding(interaction.channel.send, content=ui_text('aktivitaetscheck.antwort.01', v0=f'{ROLLE_HAUPT_POLIZEI}'), embed=e, view=AktivitaetView())
    except discord.HTTPException:
        return await send_with_branding(interaction.followup.send, ui_text('aktivitaetscheck.antwort.02'), ephemeral=True)
    with db:
        db.execute('INSERT INTO aktivitaetschecks (message_id, channel_id, start, frist) VALUES (?, ?, ?, ?)', (msg.id, msg.channel.id, time.time(), frist))
    await send_with_branding(interaction.followup.send, ui_text('aktivitaetscheck.antwort.03', v0=f'{stunden}'), ephemeral=True)

class PlatzverweisModal(SafeModal, title='Platzverweis eintragen'):
    person = discord.ui.TextInput(label=ui_text('PlatzverweisModal.label.01'), max_length=80)
    ort = discord.ui.TextInput(label=ui_text('PlatzverweisModal.label.02'), placeholder=ui_text('PlatzverweisModal.placeholder.03'), max_length=100)
    grund = discord.ui.TextInput(label=ui_text('PlatzverweisModal.label.04'), style=discord.TextStyle.paragraph, max_length=400)
    dauer = discord.ui.TextInput(label=ui_text('PlatzverweisModal.label.05'), placeholder=ui_text('PlatzverweisModal.placeholder.06'), default='24 Stunden', max_length=40)

    async def on_submit(self, interaction: discord.Interaction):
        e = text_embed('platzverweis', person=self.person.value, ort=self.ort.value, grund=self.grund.value, dauer=self.dauer.value, beamter=f'{interaction.user.mention}{nummer_tag(interaction.user.id)}')
        await send_with_branding(interaction.response.send_message, embed=e)

class PlatzverweisView(SafeView):

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label=ui_text('eintragen.label.02'), style=discord.ButtonStyle.primary, emoji='🚧', custom_id='polizei:platzverweis')
    async def eintragen(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not hat_hauptrolle(interaction.user) and (not ist_fuehrung_member(interaction.user)):
            return await send_with_branding(interaction.response.send_message, ui_text('eintragen.antwort.01'), ephemeral=True)
        await interaction.response.send_modal(PlatzverweisModal())

@bot.tree.command(name='platzverweis_panel', description='Erstellt das Platzverweis-Panel (Nur Admins)')
@app_commands.default_permissions(administrator=True)
@app_commands.checks.has_permissions(administrator=True)
async def platzverweis_panel(interaction: discord.Interaction):
    await send_with_branding(interaction.response.send_message, ui_text('platzverweis_panel.antwort.01'), ephemeral=True)
    await send_with_branding(interaction.channel.send, embed=text_embed('platzverweis_panel'), view=PlatzverweisView())

def ausbildung_embed(user_id):
    row = db.execute('SELECT * FROM ausbildung WHERE user_id=?', (user_id,)).fetchone()
    erledigt = {r['modul']: r for r in db.execute('SELECT * FROM ausbildung_module WHERE user_id=?', (user_id,))}
    gesamt = len(AUSBILDUNGS_MODULE)
    fertig = len([i for i in range(gesamt) if i in erledigt])
    balken = '▰' * fertig + '▱' * (gesamt - fertig)
    e = text_embed('ausbildung', farbe=65280 if fertig == gesamt else None, user=f'<@{user_id}>', ausbilder=f'<@{row['ausbilder_id']}>' if row else '–')
    zeilen = []
    for i, name in enumerate(AUSBILDUNGS_MODULE):
        if i in erledigt:
            r = erledigt[i]
            zeilen.append(f'✅ **{name}** – {fmt_zeit(r['erledigt'], 'd')} (<@{r['von']}>)')
        else:
            zeilen.append(f'⬜ {name}')
    e.add_field(name=field_heading(ui_text('ausbildung_embed.feld.01', v0=f'{fertig}', v1=f'{gesamt}', v2=f'{(int(fertig / gesamt * 100) if gesamt else 0)}')), value=f'{balken}\n' + '\n'.join(zeilen), inline=False)
    return e

class AusbildungSelect(discord.ui.Select):

    def __init__(self):
        optionen = [discord.SelectOption(label=m[:100], value=str(i)) for i, m in enumerate(AUSBILDUNGS_MODULE[:25])]
        super().__init__(placeholder='Modul abhaken / zurücksetzen …', options=optionen, custom_id='polizei:ausbildung:modul')

    async def callback(self, interaction: discord.Interaction):
        if not ist_ausbilder_member(interaction.user):
            return await send_with_branding(interaction.response.send_message, ui_text('callback.antwort.01'), ephemeral=True)
        row = db.execute('SELECT * FROM ausbildung WHERE message_id=?', (interaction.message.id,)).fetchone()
        if not row:
            return await send_with_branding(interaction.response.send_message, ui_text('callback.antwort.02'), ephemeral=True)
        uid, modul = (row['user_id'], int(self.values[0]))
        with db:
            if db.execute('SELECT 1 FROM ausbildung_module WHERE user_id=? AND modul=?', (uid, modul)).fetchone():
                db.execute('DELETE FROM ausbildung_module WHERE user_id=? AND modul=?', (uid, modul))
            else:
                db.execute('INSERT INTO ausbildung_module (user_id, modul, erledigt, von) VALUES (?, ?, ?, ?)', (uid, modul, time.time(), interaction.user.id))
        anzahl = db.execute('SELECT COUNT(*) c FROM ausbildung_module WHERE user_id=?', (uid,)).fetchone()['c']
        komplett = anzahl >= len(AUSBILDUNGS_MODULE)
        neu_fertig = komplett and (not row['abgeschlossen'])
        with db:
            db.execute('UPDATE ausbildung SET abgeschlossen=? WHERE user_id=?', (1 if komplett else 0, uid))
        await interaction.response.edit_message(embed=ausbildung_embed(uid), view=AusbildungView())
        if neu_fertig:
            await send_with_branding(interaction.channel.send, content=ui_text('callback.antwort.03', v0=f'{ROLLE_AUSBILDUNG_ABSCHLUSS_PING}'), embed=text_embed('ausbildung_fertig', user=f'<@{uid}>'))

class AusbildungView(SafeView):

    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(AusbildungSelect())

@bot.tree.command(name='ausbildung_start', description='Startet den Ausbildungs-Tracker für einen Anwärter')
@ist_ausbilder()
async def ausbildung_start(interaction: discord.Interaction, user: discord.Member):
    await interaction.response.defer(ephemeral=True)
    bestehend = db.execute('SELECT * FROM ausbildung WHERE user_id=?', (user.id,)).fetchone()
    if bestehend and (not bestehend['abgeschlossen']):
        return await send_with_branding(interaction.followup.send, ui_text('ausbildung_start.antwort.01'), ephemeral=True)
    with db:
        db.execute('DELETE FROM ausbildung WHERE user_id=?', (user.id,))
        db.execute('DELETE FROM ausbildung_module WHERE user_id=?', (user.id,))
        db.execute('INSERT INTO ausbildung (user_id, ausbilder_id, gestartet) VALUES (?, ?, ?)', (user.id, interaction.user.id, time.time()))
    kanal = bot.get_channel(KANAL_AUSBILDUNG) if KANAL_AUSBILDUNG else interaction.channel
    try:
        msg = await send_with_branding(kanal.send, content=ping(user.mention), embed=ausbildung_embed(user.id), view=AusbildungView())
    except (discord.HTTPException, AttributeError):
        return await send_with_branding(interaction.followup.send, ui_text('ausbildung_start.antwort.02'), ephemeral=True)
    with db:
        db.execute('UPDATE ausbildung SET message_id=?, channel_id=? WHERE user_id=?', (msg.id, msg.channel.id, user.id))
    await send_with_branding(interaction.followup.send, ui_text('ausbildung_start.antwort.03'), ephemeral=True)

@bot.tree.command(name='ausbildung_status', description='Zeigt den Ausbildungsfortschritt eines Anwärters')
@ist_ausbilder()
async def ausbildung_status(interaction: discord.Interaction, user: discord.Member):
    if not db.execute('SELECT 1 FROM ausbildung WHERE user_id=?', (user.id,)).fetchone():
        return await send_with_branding(interaction.response.send_message, ui_text('ausbildung_status.antwort.01'), ephemeral=True)
    await send_with_branding(interaction.response.send_message, embed=ausbildung_embed(user.id), ephemeral=True)

@bot.tree.command(name='ausbildung_beenden', description='Löscht den Ausbildungs-Tracker eines Anwärters (Führungsebene)')
@ist_fuehrung()
async def ausbildung_beenden(interaction: discord.Interaction, user: discord.Member):
    with db:
        c = db.execute('DELETE FROM ausbildung WHERE user_id=?', (user.id,))
        db.execute('DELETE FROM ausbildung_module WHERE user_id=?', (user.id,))
    await send_with_branding(interaction.response.send_message, '✅ Tracker gelöscht.' if c.rowcount else '❌ Kein Tracker vorhanden.', ephemeral=True)

class AnwaerterAuswahlView(SafeView):

    def __init__(self):
        super().__init__(timeout=120)

    @discord.ui.select(cls=discord.ui.UserSelect, placeholder=ui_text('auswahl.placeholder.08'), min_values=1, max_values=1)
    async def auswahl(self, interaction: discord.Interaction, select: discord.ui.UserSelect):
        if not ist_ausbilder_member(interaction.user):
            return await send_with_branding(interaction.response.send_message, ui_text('auswahl.antwort.06'), ephemeral=True)
        member = select.values[0]
        if not isinstance(member, discord.Member):
            member = interaction.guild.get_member(member.id)
        if member is None or member.bot:
            return await send_with_branding(interaction.response.send_message, ui_text('auswahl.antwort.07'), ephemeral=True)
        await ausbildung_start.callback(interaction, member)

class AusbildungPanelView(SafeView):

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label=ui_text('meine.label.04'), style=discord.ButtonStyle.primary, emoji='📘', custom_id='polizei:ap:meine')
    async def meine(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not db.execute('SELECT 1 FROM ausbildung WHERE user_id=?', (interaction.user.id,)).fetchone():
            return await send_with_branding(interaction.response.send_message, ui_text('meine.antwort.03'), ephemeral=True)
        await send_with_branding(interaction.response.send_message, embed=ausbildung_embed(interaction.user.id), ephemeral=True)

    @discord.ui.button(label=ui_text('starten.label.03'), style=discord.ButtonStyle.success, emoji='➕', custom_id='polizei:ap:start')
    async def starten(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not ist_ausbilder_member(interaction.user):
            return await send_with_branding(interaction.response.send_message, ui_text('starten.antwort.01'), ephemeral=True)
        await send_with_branding(interaction.response.send_message, ui_text('starten.antwort.02'), view=AnwaerterAuswahlView(), ephemeral=True)

    @discord.ui.button(label=ui_text('liste.label.08'), style=discord.ButtonStyle.secondary, emoji='📋', custom_id='polizei:ap:liste')
    async def liste(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not ist_ausbilder_member(interaction.user):
            return await send_with_branding(interaction.response.send_message, ui_text('liste.antwort.06'), ephemeral=True)
        rows = db.execute('SELECT * FROM ausbildung WHERE abgeschlossen=0 ORDER BY gestartet').fetchall()
        zeilen = []
        for r in rows:
            fertig = db.execute('SELECT COUNT(*) c FROM ausbildung_module WHERE user_id=?', (r['user_id'],)).fetchone()['c']
            link = f' – [Tracker](https://discord.com/channels/{interaction.guild_id}/{r['channel_id']}/{r['message_id']})' if r['message_id'] else ''
            zeilen.append(f'<@{r['user_id']}> – {fertig}/{len(AUSBILDUNGS_MODULE)} Module (Ausbilder <@{r['ausbilder_id']}>){link}')
        e = basis_embed(ui_text('liste.titel.07', v0=f'{len(rows)}'), '\n'.join(zeilen)[:4000] or '*Keine laufenden Ausbildungen.*', 255)
        await send_with_branding(interaction.response.send_message, embed=e, ephemeral=True)

@bot.tree.command(name='ausbildung_panel', description='Erstellt das Ausbildungs-Panel (Nur Admins)')
@app_commands.default_permissions(administrator=True)
@app_commands.checks.has_permissions(administrator=True)
async def ausbildung_panel(interaction: discord.Interaction):
    await send_with_branding(interaction.response.send_message, ui_text('ausbildung_panel.antwort.01'), ephemeral=True)
    await send_with_branding(interaction.channel.send, embed=text_embed('ausbildung_panel'), view=AusbildungPanelView())

@bot.tree.command(name='dienstnummer', description='Teilt einem Beamten eine Dienstnummer zu (Führungsebene)')
@ist_fuehrung()
async def dienstnummer(interaction: discord.Interaction, user: discord.Member, wunsch_nummer: str=None):
    await interaction.response.defer()
    wunsch = None
    if wunsch_nummer:
        wunsch = nummer_normalisieren(wunsch_nummer)
        if not wunsch:
            return await send_with_branding(interaction.followup.send, ui_text('dienstnummer.antwort.01', v0=f'{NUMMER_PREFIX}', v1=f'{NUMMER_PREFIX}', v2=f'{MAX_NUMMERN:02d}'), ephemeral=True)
    try:
        nummer, verdraengt = nummer_zuweisen(user.id, wunsch)
    except ValueError as err:
        return await send_with_branding(interaction.followup.send, ui_text('dienstnummer.antwort.02', v0=f'{err}'), ephemeral=True)
    await nick_setzen(user, nummer)
    e = text_embed('nummer_zugewiesen', user=user.mention, nummer=nummer)
    if verdraengt:
        v_id, v_nummer = verdraengt
        e.add_field(name=field_heading(ui_text('dienstnummer.feld.03')), value=ui_text('dienstnummer.feldwert.04', v0=f'{v_id}', v1=f'{v_nummer}'), inline=False)
        v_member = interaction.guild.get_member(v_id)
        if v_member:
            await nick_setzen(v_member, v_nummer)
    await panel_aktualisieren()
    await send_with_branding(interaction.followup.send, embed=e)
    if interaction.channel_id != KANAL_DIENSTNUMMER:
        await senden(KANAL_DIENSTNUMMER, content=ping(user.mention), embed=e)

@bot.tree.command(name='dienstnummer_freigeben', description='Gibt die Dienstnummer eines Beamten frei (Führungsebene)')
@ist_fuehrung()
async def dienstnummer_freigeben(interaction: discord.Interaction, user: discord.Member):
    await interaction.response.defer(ephemeral=True)
    nummer = await nummer_entziehen(interaction.guild, user.id, f'Manuell durch {interaction.user}')
    await send_with_branding(interaction.followup.send, f'✅ **{nummer}** wurde freigegeben.' if nummer else '❌ Dieser Beamte hat keine Dienstnummer.', ephemeral=True)

@bot.tree.command(name='dienstnummer_info', description='Zeigt die Dienstnummer eines Beamten an')
async def dienstnummer_info(interaction: discord.Interaction, user: discord.Member):
    nummer = nummer_von(user.id)
    text = f'👮\u200d♂️ {user.mention} hat die Dienstnummer **{nummer}**.' if nummer else f'❌ {user.mention} hat noch keine Dienstnummer.'
    await send_with_branding(interaction.response.send_message, text, ephemeral=True)

async def aufruecken_ausfuehren(interaction, nummer):
    """Rückt alle Nummern über der freien Nummer nach, setzt Nicknames und protokolliert. -> (aenderungen, fehler)"""
    try:
        aenderungen = aufruecken(nummer)
    except ValueError as err:
        return (None, str(err))
    for uid, alt, neu in aenderungen:
        m = interaction.guild.get_member(uid)
        if m:
            await nick_setzen(m, neu)
    if aenderungen:
        liste = '\n'.join((f'<@{uid}>: {alt} → {neu}' for uid, alt, neu in aenderungen))
        if len(liste) > 3000:
            liste = liste[:3000] + '\n…'
        await senden(KANAL_DIENSTNUMMER, embed=text_embed('aufgerueckt', nummer=nummer, anzahl=len(aenderungen), liste=liste, direktion=interaction.user.mention))
    return (aenderungen, None)

def aufruecken_antwort(nummer, aenderungen, fehler):
    if fehler:
        return f'❌ {fehler}'
    if not aenderungen:
        return f'ℹ️ Über {nummer} gibt es keine vergebenen Nummern. Es gibt nichts aufzurücken.'
    return f'✅ Aufgerückt: {len(aenderungen)} Beamte haben eine neue Dienstnummer (ab {nummer}).'

class AufrueckenView(SafeView):
    """Button unter der Meldung „Dienstnummer entzogen“."""

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label=ui_text('klick.label.05'), style=discord.ButtonStyle.primary, emoji='⬆️', custom_id='polizei:aufruecken')
    async def klick(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not ist_fuehrung_member(interaction.user):
            return await send_with_branding(interaction.response.send_message, ui_text('klick.antwort.01'), ephemeral=True)
        row = db.execute('SELECT * FROM aufrueck_offen WHERE message_id=?', (interaction.message.id,)).fetchone()
        if not row or row['erledigt']:
            return await send_with_branding(interaction.response.send_message, ui_text('klick.antwort.02'), ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        aenderungen, fehler = await aufruecken_ausfuehren(interaction, row['nummer'])
        with db:
            db.execute('UPDATE aufrueck_offen SET erledigt=1 WHERE message_id=?', (row['message_id'],))
        status = aufruecken_antwort(row['nummer'], aenderungen, fehler)
        try:
            e = interaction.message.embeds[0] if interaction.message.embeds else basis_embed(ui_text('klick.titel.03'))
            e.add_field(name=field_heading(ui_text('klick.feld.04')), value=f'{status}\nDurch {interaction.user.mention}'[:1024], inline=False)
            await interaction.message.edit(embed=e, view=None)
        except discord.HTTPException:
            pass
        await send_with_branding(interaction.followup.send, status, ephemeral=True)

class AufrueckenModal(SafeModal, title='Nummern aufrücken'):
    nummer_eingabe = discord.ui.TextInput(label=ui_text('AufrueckenModal.label.01'), placeholder=ui_text('AufrueckenModal.placeholder.02'), max_length=10)

    async def on_submit(self, interaction: discord.Interaction):
        if not ist_fuehrung_member(interaction.user):
            return await send_with_branding(interaction.response.send_message, ui_text('on_submit.antwort.01'), ephemeral=True)
        nummer = nummer_normalisieren(self.nummer_eingabe.value)
        if not nummer:
            return await send_with_branding(interaction.response.send_message, ui_text('on_submit.antwort.02'), ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        aenderungen, fehler = await aufruecken_ausfuehren(interaction, nummer)
        await send_with_branding(interaction.followup.send, aufruecken_antwort(nummer, aenderungen, fehler), ephemeral=True)

class NummernPanelView(SafeView):
    """Panel für die Führungsebene."""

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label=ui_text('abfrage.label.02'), style=discord.ButtonStyle.primary, emoji='🔎', custom_id='polizei:np:abfrage')
    async def abfrage(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not ist_fuehrung_member(interaction.user):
            return await send_with_branding(interaction.response.send_message, ui_text('abfrage.antwort.01'), ephemeral=True)
        await interaction.response.send_modal(DatenbankAbfrageModal())

    @discord.ui.button(label=ui_text('frei.label.03'), style=discord.ButtonStyle.secondary, emoji='📋', custom_id='polizei:np:frei')
    async def frei(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not ist_fuehrung_member(interaction.user):
            return await send_with_branding(interaction.response.send_message, ui_text('frei.antwort.01'), ephemeral=True)
        vergeben = db.execute('SELECT COUNT(*) c FROM dienstnummern').fetchone()['c']
        e = basis_embed(ui_text('frei.titel.02'), f'**Vergeben:** {vergeben} / {MAX_NUMMERN}\n\n{freie_bereiche()}'[:4000], 10181046)
        await send_with_branding(interaction.response.send_message, embed=e, ephemeral=True)

    @discord.ui.button(label=ui_text('aufruecken_btn.label.02'), style=discord.ButtonStyle.success, emoji='⬆️', custom_id='polizei:np:aufruecken')
    async def aufruecken_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not ist_fuehrung_member(interaction.user):
            return await send_with_branding(interaction.response.send_message, ui_text('aufruecken_btn.antwort.01'), ephemeral=True)
        await interaction.response.send_modal(AufrueckenModal())

@bot.tree.command(name='dienstnummer_panel', description='Erstellt das Dienstnummern-Panel für die Führung (Abfrage, freie Nummern, Aufrücken)')
@ist_fuehrung()
async def dienstnummer_panel(interaction: discord.Interaction):
    await send_with_branding(interaction.response.send_message, ui_text('dienstnummer_panel.antwort.01'), ephemeral=True)
    await send_with_branding(interaction.channel.send, embed=text_embed('nummern_panel'), view=NummernPanelView())

@bot.tree.command(name='abgleich', description='Gleicht Dienstnummern mit den Rollen ab (Führungsebene)')
@ist_fuehrung()
async def abgleich_cmd(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    await abgleich(interaction.guild)
    await panel_aktualisieren()
    await send_with_branding(interaction.followup.send, ui_text('abgleich_cmd.antwort.01'), ephemeral=True)

class DienstausweisModal(SafeModal, title='Dienstausweis Registrierung'):
    roblox_name = discord.ui.TextInput(label=ui_text('DienstausweisModal.label.01'), placeholder=ui_text('DienstausweisModal.placeholder.02'), required=True, max_length=50)

    async def on_submit(self, interaction: discord.Interaction):
        if not hat_hauptrolle(interaction.user):
            return await send_with_branding(interaction.response.send_message, ui_text('on_submit.antwort.03'), ephemeral=True)
        bestehend = nummer_von(interaction.user.id)
        try:
            nummer, _ = nummer_zuweisen(interaction.user.id, roblox=self.roblox_name.value.strip())
        except ValueError as err:
            return await send_with_branding(interaction.response.send_message, ui_text('on_submit.antwort.04', v0=f'{err}'), ephemeral=True)
        await send_with_branding(interaction.response.send_message, ui_text('on_submit.antwort.05', v0=f'{('Dein Eintrag wurde aktualisiert' if bestehend else 'Erfolgreich registriert')}', v1=f'{nummer}', v2=f'{self.roblox_name.value}'), ephemeral=True)
        await nick_setzen(interaction.user, nummer)
        await panel_aktualisieren()

class DienstausweisView(SafeView):

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label=ui_text('start.label.01'), style=discord.ButtonStyle.primary, custom_id='polizei:dienstausweis', emoji='🪪')
    async def start(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(DienstausweisModal())

@bot.tree.command(name='dienstausweis_setup', description='Erstellt das Dienstausweis-Panel (Nur Admins)')
@app_commands.default_permissions(administrator=True)
@app_commands.checks.has_permissions(administrator=True)
async def dienstausweis_setup(interaction: discord.Interaction):
    await send_with_branding(interaction.response.send_message, ui_text('dienstausweis_setup.antwort.01'), ephemeral=True)
    await send_with_branding(interaction.channel.send, embed=text_embed('dienstausweis_panel'), view=DienstausweisView())

class AusweisModal(SafeModal):

    def __init__(self, typ_key):
        self.typ_key = typ_key
        self.typ_name = AUSWEIS_TYPEN[typ_key][0]
        super().__init__(title=f'Antrag: {self.typ_name}'[:45])
        self.name = discord.ui.TextInput(label=ui_text('__init__.label.01'), placeholder=ui_text('__init__.placeholder.02'), max_length=80)
        self.geburtstag = discord.ui.TextInput(label=ui_text('__init__.label.03'), placeholder=ui_text('__init__.placeholder.04'), max_length=20)
        self.roblox_name = discord.ui.TextInput(label=ui_text('__init__.label.05'), placeholder=ui_text('__init__.placeholder.06'), max_length=50)
        for f in (self.name, self.geburtstag, self.roblox_name):
            self.add_item(f)

    async def on_submit(self, interaction: discord.Interaction):
        kanal = bot.get_channel(KANAL_AUSWEIS)
        if kanal is None:
            return await send_with_branding(interaction.response.send_message, ui_text('on_submit.antwort.06'), ephemeral=True)
        with db:
            cur = db.execute('INSERT INTO antraege (user_id, typ, name, geburtstag, roblox) VALUES (?, ?, ?, ?, ?)', (interaction.user.id, self.typ_key, self.name.value, self.geburtstag.value, self.roblox_name.value))
        antrag_id = cur.lastrowid
        e = basis_embed(ui_text('on_submit.titel.07', v0=f'{self.typ_name}'), farbe=10181046)
        e.add_field(name=field_heading(ui_text('on_submit.feld.08')), value=self.name.value, inline=False)
        e.add_field(name=field_heading(ui_text('on_submit.feld.09')), value=self.geburtstag.value, inline=False)
        e.add_field(name=field_heading(ui_text('on_submit.feld.10')), value=self.roblox_name.value, inline=False)
        e.add_field(name=field_heading(ui_text('on_submit.feld.11')), value=ui_text('on_submit.feldwert.12'), inline=False)
        e.set_footer(text=f'{BRANDING_FOOTER} | Antrag #{antrag_id}')
        try:
            msg = await send_with_branding(kanal.send, content=ui_text('on_submit.antwort.13', v0=f'{interaction.user.mention}'), embed=e, view=AntragView())
        except discord.HTTPException:
            return await send_with_branding(interaction.response.send_message, ui_text('on_submit.antwort.14'), ephemeral=True)
        with db:
            db.execute('UPDATE antraege SET message_id=? WHERE id=?', (msg.id, antrag_id))
        await send_with_branding(interaction.response.send_message, ui_text('on_submit.antwort.15', v0=f'{antrag_id}'), ephemeral=True)

class AusweisPanelView(SafeView):

    def __init__(self):
        super().__init__(timeout=None)
        for key, (name, emoji) in AUSWEIS_TYPEN.items():
            btn = discord.ui.Button(label=name, emoji=emoji, style=discord.ButtonStyle.primary, custom_id=f'polizei:ausweis:{key}')
            btn.callback = self._callback_fuer(key)
            self.add_item(btn)

    @staticmethod
    def _callback_fuer(key):

        async def callback(interaction: discord.Interaction):
            await interaction.response.send_modal(AusweisModal(key))
        return callback

def antrag_embed_status(message, text, farbe):
    if not message.embeds:
        return basis_embed(ui_text('antrag_embed_status.titel.01'), text, farbe)
    e = message.embeds[0]
    e.color = farbe
    gefunden = False
    for i, f in enumerate(e.fields):
        if f.name == 'Status':
            e.set_field_at(i, name='Status', value=text, inline=False)
            gefunden = True
    if not gefunden:
        e.add_field(name=field_heading(ui_text('antrag_embed_status.feld.02')), value=text, inline=False)
    return e

async def antrag_abschliessen(interaction, row, message, angenommen, grund=None):
    status = 'angenommen' if angenommen else 'abgelehnt'
    with db:
        changed = db.execute("UPDATE antraege SET status=? WHERE id=? AND status='offen'", (status, row['id'])).rowcount
    if not changed:
        raise ValueError('Dieser Antrag wurde bereits bearbeitet.')
    text = f'✅ Angenommen von {interaction.user.mention}' if angenommen else f'❌ Abgelehnt von {interaction.user.mention}\n**Grund:** {grund}'
    try:
        await message.edit(embed=antrag_embed_status(message, text, 65280 if angenommen else 16711680), view=None)
    except discord.HTTPException:
        with db:
            db.execute("UPDATE antraege SET status='offen' WHERE id=? AND status=?", (row['id'], status))
        raise
    typ_name = AUSWEIS_TYPEN.get(row['typ'], (row['typ'],))[0]
    member = interaction.guild.get_member(row['user_id'])
    hinweis = ''
    if angenommen and member and (row['typ'] in AUSWEIS_ROLLEN):
        rolle = interaction.guild.get_role(AUSWEIS_ROLLEN[row['typ']])
        if rolle:
            fehler = await rollen_aendern(member, add=[rolle], grund=f'Antrag #{row['id']} angenommen')
            hinweis = f'\n⚠️ Rolle konnte nicht vergeben werden: {fehler}' if fehler else ''
    e = text_embed('antrag_angenommen' if angenommen else 'antrag_abgelehnt', typ=typ_name, id=row['id'], grund=grund or '–')
    try:
        await send_with_branding((member or await bot.fetch_user(row['user_id'])).send, embed=e)
    except (discord.Forbidden, discord.HTTPException, discord.NotFound):
        await send_with_branding(message.reply, ui_text('antrag_abschliessen.antwort.01', v0=f'{row['user_id']}'), embed=e)
    return hinweis

class AblehnenModal(SafeModal, title='Antrag ablehnen'):
    grund = discord.ui.TextInput(label=ui_text('AblehnenModal.label.01'), style=discord.TextStyle.paragraph, max_length=500)

    def __init__(self, row, message):
        super().__init__()
        self.row, self.message = (row, message)

    async def on_submit(self, interaction: discord.Interaction):
        if not ist_fuehrung_member(interaction.user):
            return await send_with_branding(interaction.response.send_message, ui_text('on_submit.antwort.16'), ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        await antrag_abschliessen(interaction, self.row, self.message, False, self.grund.value)
        await send_with_branding(interaction.followup.send, ui_text('on_submit.antwort.17'), ephemeral=True)

class AntragView(SafeView):

    def __init__(self):
        super().__init__(timeout=None)

    async def _laden(self, interaction):
        if not ist_fuehrung_member(interaction.user):
            await send_with_branding(interaction.response.send_message, ui_text('_laden.antwort.01'), ephemeral=True)
            return None
        row = db.execute('SELECT * FROM antraege WHERE message_id=?', (interaction.message.id,)).fetchone()
        if not row or row['status'] != 'offen':
            await send_with_branding(interaction.response.send_message, ui_text('_laden.antwort.02'), ephemeral=True)
            return None
        return row

    @discord.ui.button(label=ui_text('annehmen.label.01'), style=discord.ButtonStyle.success, emoji='✅', custom_id='polizei:antrag:ok')
    async def annehmen(self, interaction: discord.Interaction, button: discord.ui.Button):
        row = await self._laden(interaction)
        if not row:
            return
        await interaction.response.defer(ephemeral=True)
        hinweis = await antrag_abschliessen(interaction, row, interaction.message, True)
        await send_with_branding(interaction.followup.send, '✅ Antrag angenommen.' + hinweis, ephemeral=True)

    @discord.ui.button(label=ui_text('ablehnen.label.01'), style=discord.ButtonStyle.danger, emoji='❌', custom_id='polizei:antrag:nein')
    async def ablehnen(self, interaction: discord.Interaction, button: discord.ui.Button):
        row = await self._laden(interaction)
        if row:
            await interaction.response.send_modal(AblehnenModal(row, interaction.message))

@bot.tree.command(name='ausweis_panel', description='Erstellt das Ausweis-Antragspanel (Nur Admins)')
@app_commands.default_permissions(administrator=True)
@app_commands.checks.has_permissions(administrator=True)
async def ausweis_panel(interaction: discord.Interaction):
    await send_with_branding(interaction.response.send_message, ui_text('ausweis_panel.antwort.01'), ephemeral=True)
    await send_with_branding(interaction.channel.send, embed=text_embed('ausweis_panel'), view=AusweisPanelView())

class DatenbankAbfrageModal(SafeModal, title='Polizeiliches Register'):
    suchbegriff = discord.ui.TextInput(label=ui_text('DatenbankAbfrageModal.label.01'), placeholder=ui_text('DatenbankAbfrageModal.placeholder.02'), required=True, max_length=50)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        eingabe = self.suchbegriff.value.strip().lstrip('@')
        nummer_check = nummer_normalisieren(eingabe)
        if nummer_check:
            ergebnis = db.execute('SELECT user_id, roblox FROM dienstnummern WHERE nummer=?', (nummer_check,)).fetchone()
        else:
            ergebnis = db.execute('SELECT user_id, roblox FROM dienstnummern WHERE LOWER(roblox)=?', (eingabe.lower(),)).fetchone()
        if not ergebnis:
            e = basis_embed(ui_text('on_submit.titel.18'), farbe=16711680)
            if nummer_check:
                e = basis_embed(ui_text('on_submit.titel.19'), ui_text('on_submit.text.20', v0=f'{nummer_check}'), 65280)
                return await send_with_branding(interaction.followup.send, embed=e, ephemeral=True)
            e.description = f'Für die Eingabe **`{eingabe}`** konnte kein Eintrag im Register gefunden werden.\nBitte überprüfe die Schreibweise.'
            return await send_with_branding(interaction.followup.send, embed=e, ephemeral=True)
        uid = ergebnis['user_id']
        roblox = ergebnis['roblox'] or 'Nicht hinterlegt'
        nummer = nummer_von(uid) or 'Keine'
        member = interaction.guild.get_member(uid)
        discord_name = member.mention if member else f'Verlassen (`{uid}`)'
        e = basis_embed(ui_text('on_submit.titel.21'), farbe=2841599)
        e.description = 'Abfrage erfolgreich abgeschlossen. Hier sind die Daten des gesuchten Beamten:'
        e.add_field(name=field_heading(ui_text('on_submit.feld.22')), value=discord_name, inline=False)
        e.add_field(name=field_heading(ui_text('on_submit.feld.23')), value=ui_text('on_submit.feldwert.24', v0=f'{nummer}'), inline=True)
        e.add_field(name=field_heading(ui_text('on_submit.feld.25')), value=ui_text('on_submit.feldwert.26', v0=f'{roblox}'), inline=True)
        await send_with_branding(interaction.followup.send, embed=e, ephemeral=True)

class DatenbankView(SafeView):

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label=ui_text('abfrage.label.04'), style=discord.ButtonStyle.secondary, emoji='🖥️', custom_id='polizei:datenbank:abfrage')
    async def abfrage(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not hat_hauptrolle(interaction.user) and (not ist_fuehrung_member(interaction.user)):
            return await send_with_branding(interaction.response.send_message, ui_text('abfrage.antwort.03'), ephemeral=True)
        await interaction.response.send_modal(DatenbankAbfrageModal())

@bot.tree.command(name='datenbank_panel', description='Erstellt das Polizeiliche Datenbank-Panel (Nur Admins)')
@app_commands.default_permissions(administrator=True)
@app_commands.checks.has_permissions(administrator=True)
async def datenbank_panel(interaction: discord.Interaction):
    await send_with_branding(interaction.response.send_message, ui_text('datenbank_panel.antwort.01'), ephemeral=True)
    e = basis_embed(ui_text('datenbank_panel.titel.02'), ui_text('datenbank_panel.text.03', v0=f'{BRANDING_FOOTER}'), 2841599)
    await send_with_branding(interaction.channel.send, embed=e, view=DatenbankView())
