import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

def setup_logging(folder):
    path=Path(folder)
    path.mkdir(parents=True,exist_ok=True)
    handlers=[logging.StreamHandler(),RotatingFileHandler(path/"polizei.log",maxBytes=2_000_000,backupCount=3,encoding="utf-8")]
    formatter=logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    for h in handlers:h.setFormatter(formatter)
    logging.basicConfig(level=logging.INFO,handlers=handlers,force=True)
def log_print(*parts,**kwargs):
    logging.getLogger("polizei").info(" ".join(map(str,parts)))
