"""
Leitstelle Berlin | Polizei-RP Discord-Bot
Benötigt: Python 3.10+, `pip install -U discord.py`
Start:    DISCORD_TOKEN=dein_token python bot.py

Optionale Umgebungsvariablen:
  GUILD_ID   Server-ID -> Slash-Commands erscheinen sofort (sonst bis zu 1h Verzögerung)
  DATA_DIR   Ordner für die Datenbank (bei Hostern: Pfad zum Persistent Volume)
"""
import datetime
import logging
from pathlib import Path
from dotenv import load_dotenv
load_dotenv(Path(__file__).resolve().parents[1] / '.env')
from .design import DESIGN, ui_text, field_heading
from .framework import SafeView, SafeModal, SafeCommandTree, confirm_action_local, send_with_branding
from .storage import open_database, create_indexes
import json
import os
import random
import re
import sqlite3
import string
import time
import discord
from discord import app_commands
from discord.ext import commands, tasks
TOKEN = os.getenv('DISCORD_TOKEN')
GUILD_ID = int(os.getenv('GUILD_ID', '1354357206698688542'))
DATA_DIR = os.getenv('DATA_DIR', str(Path(__file__).resolve().parents[1] / 'data'))
BRANDING_NAME = DESIGN['branding']['name']
BRANDING_FOOTER = DESIGN['branding']['footer']
NUMMER_PREFIX = 'BLP'
MAX_NUMMERN = 500
AUTO_DIENSTNUMMER = False
AUTO_NICKNAME = True
AUTO_VERGABE_BEIM_START = False
MELDUNG_PING = False
AKTIVITAETSCHECK_AUTO_WARN = True
AKTIVITAETSCHECK_WARN_TAGE = 7
AUTO_AUSSTEMPELN_NACH_STUNDEN = 8
WOCHENSOLL_STUNDEN = 2.0
WOCHENBERICHT_TAG = 6
WOCHENBERICHT_UHRZEIT = (20, 0)
ZEITZONE = 'Europe/Berlin'
AUSBILDUNGS_MODULE = ['Theorie / Rechtsgrundlagen', 'Funkdisziplin', 'Streifendienst (Praxis)', 'Festnahme & Eigensicherung', 'Verkehrskontrolle', 'Abschlussprüfung']
ROLLE_ANWALT = 1561406761796247592
ROLLE_HAUPT_POLIZEI = 1561447435522539702
ROLLE_AUSBILDUNG_ABSCHLUSS_PING = 1561139929894092960
ROLLEN_WARN = [1561306415904071812, 1561306491879825468, 1561306575958712370]
ROLLE_SUSPENDIERT = 1561306288799883345
ROLLE_ENTLASSEN = 1561306221343023141
ROLLE_DIENSTSPERRE = 1561306075746140260
ROLLEN_FUEHRUNG = [1561139230988705914, 1561139458068320349, 1561139621633593455, 1561139825070051348, 1561139929894092960, 1561140168738603170, 1561140325974802602, 1561140440181506218]
KANAL_ANWALT = 1561113869156352020
KANAL_AUSWEIS = 1561401078300418121
KANAL_DIENSTZEIT = 1561407060036427776
KANAL_EINSTELLUNG = 1561115548610199633
KANAL_BEFOERDERUNG = 1561115864177319936
KANAL_DEGRADIERUNG = 1561115982670471309
KANAL_WARN = 1561116201323733043
KANAL_SUSPENDIERUNG = 1561116388007878746
KANAL_ENTLASSUNG = 1561116526621364445
KANAL_SPERREN = 1561116717906657380
KANAL_BEWERBUNGSSPERRE = KANAL_SPERREN
KANAL_DIENSTNUMMER = 1561115548610199633
KANAL_DIENSTNUMMER_PANEL = 1561407060036427776
KANAL_WOCHENBERICHT = 0
KANAL_AUSBILDUNG = 0
KANAL_DIENSTZEIT_LOG = 1561407060036427776
KANAL_DIENSTZEIT_LOG_FUEHRUNG = 1563949298209652896
AUSWEIS_ROLLEN = {}
TEAMLISTE_RAENGE = [('Inspekteur', 1561139230988705914, 'Führung'), ('[PP] Polizeipräsident', 1561139458068320349, 'Führung'), ('[VPP] Vize Polizei Präsident', 1561139621633593455, 'Führung'), ('[LPV] Leitende Personalverwaltung', 1561139825070051348, 'Führung'), ('[PV] Personalverwaltung', 1561139929894092960, 'Führung'), ('[LPD] Leitender Polizeidirektor', 1561140168738603170, 'Führung'), ('[LKD] Leitender Kriminaldirektor', 1561140325974802602, 'Führung'), ('[LSD] Leitender SEK Direktor', 1561140440181506218, 'Führung'), ('[PD] Polizeidirektor', 1561140798597369957, 'Führung'), ('[KD] Kriminaldirektor', 1561140917409419367, 'Führung'), ('[SD] SEK Direktor', 1561141052478587002, 'Führung'), ('[PR] Polizeirat', 1561141205411168318, 'Führung'), ('[KA] Kripo Ausbilder', 1561143144299368479, 'Ausbilder'), ('[SA] SEK Ausbilder', 1561143260842299412, 'Ausbilder'), ('[PA] Polizei Ausbilder', 1561143365574336533, 'Ausbilder'), ('[PHK] Polizei Hauptkommissar', 1561143539444752404, 'Polizei'), ('[POK] Polizeioberskommissar', 1561143760786817085, 'Polizei'), ('[PK] Polizeikommissar', 1561143936725028874, 'Polizei'), ('[KHK] Kriminalhauptkommissar', 1561144156061962260, 'Kripo'), ('[KOK] Kriminaloberkommissar', 1561144421263740928, 'Kripo'), ('[KK] Kriminalkommissar', 1561145174317469856, 'Kripo'), ('[KOA] Kripo Anwärter', 1561145321067913326, 'Kripo'), ('[SEK] Einsatzleiter', 1561146093432209471, 'SEK'), ('[SEK] Verhandler', 1561146166970687549, 'SEK'), ('[SEK] Fahrzeugführer', 1561146259337650197, 'SEK'), ('[SEK] Sniper', 1561146387859513434, 'SEK'), ('[SEK] Beamter', 1561146470479167649, 'SEK'), ('[SEK] Anwärter', 1561146568151793766, 'SEK'), ('[PHM] Polizeihauptmeister', 1561146826252619847, 'Polizei'), ('[POM] Polizeiobermeister', 1561146956665856183, 'Polizei'), ('[PM] Polizeimeister', 1561147088396357802, 'Polizei'), ('[PMA] Polizeimeisteranwärter', 1561147205186748486, 'Polizei')]
AUSWEIS_TYPEN = {'personalausweis': ('Personalausweis', '🪪'), 'fs_pkw': ('Führerschein PKW', '🚗'), 'fs_lkw': ('Führerschein LKW', '🚚'), 'fs_motorrad': ('Führerschein Motorrad', '🏍️'), 'waffe_klein': ('Kleiner Waffenschein', '🔫'), 'waffe_gross': ('Großer Waffenschein', '🔫')}
TEXTE = DESIGN['templates']
HILFE = [('🧑\u200d✈️ Beamte', 'alle', [('/dienstzeit', 'Ein- oder Ausstempeln'), ('/dienstzeit_info', 'Deine Dienstzeit der letzten 7 und 30 Tage'), ('/dienstnummer_info', 'Dienstnummer eines Beamten anzeigen'), ('/teamliste', 'Aktuelle Teamliste'), ('/hilfe', 'Diese Übersicht')]), ('👥 Panels (Buttons)', 'alle', [('Dienstausweis-Panel', 'Dienstnummer selbst freischalten'), ('Ausweis-Panel', 'Personalausweis, Führerschein, Waffenschein beantragen'), ('Platzverweis-Panel', 'Platzverweis eintragen'), ('Datenbank-Panel', 'Dienstnummern & Roblox-Namen abfragen (nur Beamte)'), ('Wort „Anwalt“', 'Im Anwalt-Kanal schreiben, um einen Anwalt zu rufen')]), ('🎓 Ausbilder', 'ausbilder', [('/ausbildung_start', 'Ausbildungs-Tracker für einen Anwärter starten'), ('/ausbildung_status', 'Fortschritt eines Anwärters ansehen')]), ('🛡️ Führung', 'fuehrung', [('/einstellung', 'Beamten einstellen (Rang + Beamten-Rolle)'), ('/befoerderung · /degradierung', 'Rang ändern (alte Rolle wird entfernt)'), ('/entlassung', 'Entlassen, Rollen entfernen, Nummer freigeben, Entlassen-Rolle vergeben'), ('/warn · /warns · /warn_entfernen', 'Disziplinarmaßnahmen (Rollen Warn 1/2/3 automatisch)'), ('/suspendierung · /suspendierung_aufheben', 'Suspendierung mit Rolle'), ('/dienstsperre · /dienstsperre_aufheben', 'Dienstsperre mit Rolle (läuft automatisch ab)'), ('/bewerbungssperre · /bewerbungssperre_pruefen', 'Bewerbungssperre für Nutzer'), ('/aktivitaetscheck', 'Aktivitätscheck mit Frist starten'), ('/wochenbericht', 'Wochenbericht sofort posten'), ('/dienstnummer · /dienstnummer_freigeben', 'Dienstnummern zuweisen bzw. freigeben'), ('Dienstnummern-Panel', 'Nummer abfragen, freie Nummern ansehen, Nummern aufrücken (auch per Button unter der Freigabe-Meldung)'), ('/abgleich', 'Nummern mit Rollen abgleichen'), ('/ausbildung_beenden', 'Tracker eines Anwärters löschen'), ('/ausweis_panel · /dienstausweis_setup · /platzverweis_panel · /anwalt_panel · /dienstzeit_panel · /dienstzeit_panel_fuehrung · /dienstnummer_panel · /ausbildung_panel · /datenbank_panel', 'Panels erstellen (Admin)')])]

CONFIG_FILE = Path(__file__).resolve().parents[1] / "server_config.json"
if CONFIG_FILE.exists():
    with CONFIG_FILE.open(encoding="utf-8") as handle:
        overrides = json.load(handle)
    for key, value in overrides.items():
        if key.isupper() and key in globals() and key not in ("TOKEN", "GUILD_ID", "DATA_DIR", "TEXTE", "HILFE", "DESIGN", "BRANDING_NAME", "BRANDING_FOOTER"):
            globals()[key] = value
for key, value in list(globals().items()):
    if key.startswith(("KANAL_", "ROLLE_")) and (isinstance(value,bool) or not isinstance(value,int) or value < 0):
        raise ValueError(f"{key} muss eine nichtnegative Ganzzahl sein.")
if not 1 <= MAX_NUMMERN <= 100000:
    raise ValueError("Ungültiger Bereich für MAX_NUMMERN.")
