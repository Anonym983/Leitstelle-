# Polizei Berlin · Vollständiges Bot-Paket

Dieses Paket wurde erneut vollständig aus deiner Originaldatei und den vereinbarten Designvorgaben zusammengestellt. Es ist kein Patch und braucht keine vorherigen ZIPs. Die bestehende Fachlogik wurde übernommen und gezielt überarbeitet; keine Behauptung einer vollständig unabhängigen Neuentwicklung oder eines vollständigen Sicherheitsaudits.

## Dateien

- bot.py: Einstiegspunkt für den Hoster.
- polizei/core.py: bestehende Befehle, Panels und Abläufe.
- polizei/configuration.py: Laden der Konfiguration.
- polizei/design.py: zentraler Designzugriff.
- polizei/framework.py: Interaktionsprüfungen, Fehlerbehandlung, Bestätigung und Banner-Anhänge.
- polizei/storage.py: Datenbank, Backups und Indizes.
- polizei/logging_setup.py: rotierende Logs.
- design.json: 33 Hauptvorlagen und 170 zusätzliche Beschriftungen/Antwortbausteine.
- VORSCHAU.html: lokale Designvorschau und Editor.
- vorschau_erstellen.py: Vorschau neu erzeugen.
- server_config.json: aus deiner ursprünglichen Datei übernommene Rollen, Kanäle, Ränge und Schalter.
- .env.example: Vorlage für geheime lokale Einstellungen.
- requirements.txt: Python-Abhängigkeiten.
- BEFEHLE.json: Liste aller 35 bisherigen Befehle mit Parametern.
- tests/test_offline.py und TESTBERICHT.txt: Offline-Prüfungen.

## Installation auf Bot-Hosting.net

1. Bisherige Instanz stoppen, bisherigen Code, Konfigurationen und vollständigen Datenordner sichern. Eine laufende SQLite-Datenbank nicht einfach kopieren; nach sauberem Stoppen den ganzen Datenordner einschließlich eventuell vorhandener Begleitdateien sichern.
2. ZIP entpacken und gesamten Projektinhalt in den Hosting-Hauptordner hochladen. bot.py, requirements.txt und polizei/ liegen nebeneinander. Nicht nur bot.py hochladen.
3. Python auswählen; Python 3.12 empfohlen. Abhängigkeiten über requirements.txt installieren lassen. Lokal: `python -m pip install -r requirements.txt`.
4. Startdatei bot.py. Lokal: `python bot.py`.
5. .env.example als .env kopieren. DISCORD_TOKEN nur lokal beim Hoster eintragen, nie verschicken. GUILD_ID prüfen.
6. DATA_DIR zeigt auf den Ordner deiner polizei.db. Vorgabe ist ./data. Für bestehende Daten den bisherigen Ordner korrekt angeben. Ein leerer Datenordner erzeugt einen frischen Bestand.
7. server_config.json prüfen. Eigene bisherige Änderungen zusammenführen statt blind überschreiben. Alte Textänderungen aus texte.json ggf. in die neue design.json übertragen.
8. Im Discord Developer Portal die von deinen Funktionen verwendeten Server Members und Message Content Intents aktivieren.
9. Serverrechte prüfen: Kanäle sehen, Nachrichten senden, Links einbetten, Dateien anhängen, Verlauf lesen. Für die betreffenden Funktionen Rollen und Nicknames verwalten; für das Löschen des Anwalt-Auslösers Nachrichten verwalten. Die Bot-Rolle muss oberhalb der verwalteten Rollen stehen. Nicht pauschal Administrator vergeben.
10. Bot starten, Logs lesen und zuerst Testmitglieder benutzen. Nicht gleichzeitig die alte und die neue Instanz laufen lassen.

## Design und Banner

Siehe DESIGN_ANLEITUNG.txt. Die Hauptthemen sind fett mit Doppelpunkt, ohne Unterstreichen; normale Emojis und keine zusätzliche Autor-/Kategoriezeile unter dem Namen.

Standardmäßig wird polizei_berlin_banner.png an neue Embed-Nachrichten angehängt. Kein externer Bildhost erforderlich. Die Datei im Hauptordner lassen und Dateien-anhängen-Recht geben.

In design.json unter branding kann banner_mode auf attachment, url oder none gesetzt werden. Nur im Modus url wird EMBED_BANNER_URL in .env benötigt. Der Banner-Schriftzug selbst ist eine PNG-Datei; eine Änderung des Branding-Namens allein ändert nicht die Schrift im Bild.

Alte Panelnachrichten ändern sich nicht automatisch. Gewünschte Panels mit den bestehenden Setup-Befehlen neu erstellen. Alte Nachrichten ohne Banner-Anhang bekommen bei einer späteren reinen Bearbeitung nicht automatisch einen neuen Anhang.

## Funktionen und Grenzen

Alle 35 ursprünglichen Befehlsnamen und Parameter bleiben erhalten, ebenso die bisherigen persistenten Custom-IDs. Keine Einsatzverwaltung, keine neuen Slash-Befehle, keine animierten Custom-Emojis. Bestehende Panelzuordnungen funktionieren nur mit den passenden übernommenen Datenbankeinträgen; das wurde hier nicht live geprüft.

Entlassungen haben einen Bestätigungsdialog. Rollenänderungen prüfen zusätzlich Botrechte und Hierarchie. Antragsentscheidungen verwenden einen bedingten Statuswechsel gegen doppelte Bearbeitung; eine fehlgeschlagene Nachrichtenbearbeitung setzt den Status zurück. Rollenereignisse fremder Server werden abgefangen. Aktivitätsbestätigungen nach Fristablauf werden abgewiesen.

SQLite-Zugriffe bleiben synchron. Beim Start bestehender Daten wird ein Backup erstellt, die letzten fünf Startbackups bleiben erhalten. Datenbank, Backups und Logs enthalten möglicherweise vertrauliche Community-Daten und gehören nicht öffentlich ins Netz.

Keine automatische Roblox-/Notruf-Hamburg-Spielanbindung und keine Verifizierung der Roblox-Namen. Ausschließlich fiktive RP-Daten verwenden.

## Vor dem Onlinegang

- /hilfe, /teamliste und benötigte Panels prüfen.
- Mit Testmitgliedern einstellen, befördern, verwarnen, sperren und aufheben.
- Dienst ein-/ausstempeln und gespeicherte Zeit prüfen.
- Dienstnummer vergeben, abfragen und freigeben; Aufrücken nur mit Testdaten versuchen.
- Ausbildung starten, Module ändern und Status prüfen.
- Dokumentenantrag einreichen und bearbeiten.
- Bot neu starten und Daten sowie bestehende Panelbuttons kontrollieren.

## Tests

`python -m unittest discover -s tests -v`

Zwölf Offline-Tests erfolgreich ausgeführt. Zusätzlich Projektimport, Templateformatierung und Banner-Anhang mit vereinfachten Discord-Testobjekten sowie Vorschau und JSON-Export mit Node geprüft. Kein echter discord.py-Laufzeittest und kein Discord-Livetest in dieser Umgebung. Keine Garantie für produktionsgeprüften, fehlerfreien Betrieb. Vor der Freigabe auf einem Testserver mit Datenbankkopie prüfen.
